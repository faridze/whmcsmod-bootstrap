# Read-only discovery and local repository import for existing WHMCS modules.
# Import never mutates WHMCS_ROOT and never pushes to a remote repository.

import_reset_scan() {
  unset IMPORT_CLASS IMPORT_KIND IMPORT_SECRET IMPORT_COMPONENT IMPORT_REASON IMPORT_UNSAFE_REASON IMPORT_UNSAFE_CLASS
  declare -gA IMPORT_CLASS=()
  declare -gA IMPORT_KIND=()
  declare -gA IMPORT_SECRET=()
  declare -gA IMPORT_COMPONENT=()
  declare -gA IMPORT_REASON=()
  declare -gA IMPORT_UNSAFE_REASON=()
  declare -gA IMPORT_UNSAFE_CLASS=()
}

import_relative_is_safe() {
  local relative="$1" part
  [[ -n "$relative" && "$relative" != /* && "$relative" =~ ^[A-Za-z0-9._/-]+$ ]] || return 1
  IFS='/' read -r -a _import_parts <<< "$relative"
  for part in "${_import_parts[@]}"; do
    [[ -n "$part" && "$part" != '..' ]] || return 1
  done
}

import_relative_path() {
  local path="$1"
  [[ "$path" == "$WHMCS_ROOT/"* ]] || return 1
  printf '%s\n' "${path#$WHMCS_ROOT/}"
}

import_component_for_path() {
  local relative="$1" rest type
  case "$relative" in
    modules/*)
      rest="${relative#modules/}"
      type="${rest%%/*}"
      type="${type^^}"
      type="${type//[^A-Z0-9]/_}"
      [[ -n "$type" ]] || type=MODULE
      printf '%s\n' "$type"
      ;;
    includes/hooks/*) printf '%s\n' HOOK ;;
    crons/*) printf '%s\n' CRON ;;
    assets/*) printf '%s\n' ASSET ;;
    templates/*) printf '%s\n' TEMPLATE ;;
    *) printf '%s\n' OTHER ;;
  esac
}

import_php_candidate() {
  local lower="${1,,}"
  [[ "$lower" == *.php || "$lower" == *.phtml || "$lower" == *.inc ]]
}

import_php_kind() {
  local file="$1" first
  if ! import_php_candidate "$file"; then
    printf '%s\n' ASSET
    return 0
  fi

  first="$(LC_ALL=C head -n 1 -- "$file" 2>/dev/null || true)"
  if {
    [[ "$first" =~ ^\<\?php[[:space:]]+//[0-9A-Za-z]{4,} ]] && \
      LC_ALL=C head -c 65536 -- "$file" 2>/dev/null | grep -aEiq 'ioncube_loader_|ionCube Loader';
  } || LC_ALL=C head -c 131072 -- "$file" 2>/dev/null | \
      grep -aEiq 'encoded by (the )?ioncube|ioncube_(loader_iversion|loader_version|file_is_encoded|read_file)|_il_exec'; then
    printf '%s\n' IONCUBE
    return 0
  fi

  if ! LC_ALL=C grep -Iq . -- "$file" 2>/dev/null; then
    printf '%s\n' UNKNOWN_PHP
    return 0
  fi
  if LC_ALL=C grep -aFq '<?' -- "$file" 2>/dev/null; then
    printf '%s\n' SOURCE
  else
    printf '%s\n' UNKNOWN_PHP
  fi
}

import_secret_risk() {
  local file="$1"
  LC_ALL=C grep -aEiq -- '-----BEGIN ([A-Z0-9 ]+ )?PRIVATE KEY-----' "$file" 2>/dev/null && return 0

  # Avoid random matches inside binary assets. Text configuration/source files are
  # checked for common PHP, JSON/YAML and dotenv-style credential assignments.
  LC_ALL=C grep -Iq . -- "$file" 2>/dev/null || return 1
  LC_ALL=C grep -Eiq -- "['\"]?(password|passwd|api[_-]?key|apikey|secret|token|access[_-]?token|client[_-]?secret|license([_-]?key)?)['\"]?[[:space:]]*(=>|:|=)[[:space:]]*['\"][^'\"]{4,}['\"]" "$file" 2>/dev/null && return 0
  LC_ALL=C grep -Eiq -- "^[[:space:]]*(password|passwd|api[_-]?key|apikey|secret|token|access[_-]?token|client[_-]?secret|license([_-]?key)?)[[:space:]]*=[[:space:]]*[^#[:space:]][^[:space:]]{3,}" "$file" 2>/dev/null && return 0
  LC_ALL=C grep -Eiq -- "define[[:space:]]*\([[:space:]]*['\"](password|passwd|api[_-]?key|apikey|secret|token|access[_-]?token|client[_-]?secret|license([_-]?key)?)['\"][[:space:]]*,[[:space:]]*['\"][^'\"]{4,}['\"]" "$file" 2>/dev/null && return 0
  LC_ALL=C grep -Eiq -- "authorization[[:space:]_-]*[:=][[:space:]]*['\"]?bearer[[:space:]]+[A-Za-z0-9._~+/=-]{8,}" "$file" 2>/dev/null && return 0
  return 1
}

import_record_unsafe() {
  local class="$1" path="$2" reason="$3" relative
  relative="$(import_relative_path "$path" 2>/dev/null || true)"
  [[ -n "$relative" ]] || relative="$path"
  IMPORT_UNSAFE_CLASS["$relative"]="$class"
  IMPORT_UNSAFE_REASON["$relative"]="$reason"
}

import_add_file() {
  local class="$1" file="$2" reason="$3" component="${4:-}" relative current
  [[ "$file" == "$WHMCS_ROOT/"* ]] || return 0
  relative="$(import_relative_path "$file")" || return 0
  if ! import_relative_is_safe "$relative"; then
    import_record_unsafe "$class" "$file" unsafe-path-name
    return 0
  fi
  if [[ -L "$file" ]]; then
    import_record_unsafe "$class" "$file" symlink
    return 0
  fi
  if [[ ! -f "$file" ]]; then
    import_record_unsafe "$class" "$file" special-entry
    return 0
  fi
  [[ -n "$component" ]] || component="$(import_component_for_path "$relative")"

  current="${IMPORT_CLASS[$relative]-}"
  case "$current:$class" in
    CONFIRMED:LIKELY|CONFIRMED:UNKNOWN|LIKELY:UNKNOWN) return 0 ;;
  esac
  IMPORT_CLASS["$relative"]="$class"
  IMPORT_COMPONENT["$relative"]="$component"
  IMPORT_REASON["$relative"]="$reason"
  IMPORT_KIND["$relative"]="$(import_php_kind "$file")"
  if import_secret_risk "$file"; then IMPORT_SECRET["$relative"]=yes; else IMPORT_SECRET["$relative"]=no; fi
}

import_add_tree() {
  local class="$1" directory="$2" reason="$3" component="${4:-}" entry relative
  [[ -e "$directory" || -L "$directory" ]] || return 0
  if [[ -L "$directory" ]]; then
    import_record_unsafe "$class" "$directory" symlink-directory
    return 0
  fi
  [[ -d "$directory" ]] || {
    import_record_unsafe "$class" "$directory" expected-directory
    return 0
  }
  while IFS= read -r -d '' entry; do
    if [[ -f "$entry" && ! -L "$entry" ]]; then
      import_add_file "$class" "$entry" "$reason" "$component"
    elif [[ -L "$entry" ]]; then
      import_record_unsafe "$class" "$entry" symlink
    else
      relative="$(import_relative_path "$entry" 2>/dev/null || true)"
      import_record_unsafe "$class" "$entry" "special-entry:${relative:-unknown}"
    fi
  done < <(find "$directory" -xdev -mindepth 1 ! -type d -print0)
}

import_scan_confirmed() {
  local module="$1" modules_root="$WHMCS_ROOT/modules" type_dir nested component
  if [[ -d "$modules_root" && ! -L "$modules_root" ]]; then
    shopt -s nullglob
    for type_dir in "$modules_root"/*; do
      [[ -d "$type_dir" && ! -L "$type_dir" ]] || continue
      component="$(basename "$type_dir")"
      component="${component^^}"
      component="${component//[^A-Z0-9]/_}"
      import_add_tree CONFIRMED "$type_dir/$module" "module-directory" "$component"
      [[ ! -e "$type_dir/$module.php" && ! -L "$type_dir/$module.php" ]] || \
        import_add_file CONFIRMED "$type_dir/$module.php" "module-entrypoint" "$component"
      for nested in callback callbacks; do
        [[ -d "$type_dir/$nested" && ! -L "$type_dir/$nested" ]] || continue
        import_add_tree CONFIRMED "$type_dir/$nested/$module" "nested-module-directory" "${component}_${nested^^}"
        [[ ! -e "$type_dir/$nested/$module.php" && ! -L "$type_dir/$nested/$module.php" ]] || \
          import_add_file CONFIRMED "$type_dir/$nested/$module.php" "nested-module-entrypoint" "${component}_${nested^^}"
      done
    done
    shopt -u nullglob
  fi

  import_add_tree CONFIRMED "$WHMCS_ROOT/includes/hooks/$module" "hook-directory" HOOK
  [[ ! -e "$WHMCS_ROOT/includes/hooks/$module.php" && ! -L "$WHMCS_ROOT/includes/hooks/$module.php" ]] || \
    import_add_file CONFIRMED "$WHMCS_ROOT/includes/hooks/$module.php" "hook-entrypoint" HOOK
  import_add_tree CONFIRMED "$WHMCS_ROOT/crons/$module" "cron-directory" CRON
  [[ ! -e "$WHMCS_ROOT/crons/$module.php" && ! -L "$WHMCS_ROOT/crons/$module.php" ]] || \
    import_add_file CONFIRMED "$WHMCS_ROOT/crons/$module.php" "cron-entrypoint" CRON
}

import_scan_likely_tree() {
  local module="$1" root="$2" path base lower module_lower="${module,,}"
  [[ -d "$root" && ! -L "$root" ]] || return 0
  while IFS= read -r -d '' path; do
    base="$(basename "$path")"
    lower="${base,,}"
    [[ "$lower" == *"$module_lower"* ]] || continue
    if [[ -L "$path" ]]; then
      import_record_unsafe LIKELY "$path" symlink
    elif [[ -f "$path" ]]; then
      import_add_file LIKELY "$path" "name-match"
    else
      import_record_unsafe LIKELY "$path" special-entry
    fi
  done < <(find "$root" -xdev -mindepth 1 ! -type d -print0)
}

import_scan_content_references() {
  local module="$1" root path relative
  ((${#module} >= 4)) || return 0
  for root in "$WHMCS_ROOT/includes/hooks" "$WHMCS_ROOT/crons"; do
    [[ -d "$root" && ! -L "$root" ]] || continue
    while IFS= read -r -d '' path; do
      relative="$(import_relative_path "$path" 2>/dev/null || true)"
      [[ -n "$relative" && -z "${IMPORT_CLASS[$relative]+x}" ]] || continue
      LC_ALL=C grep -I -F -i -q -- "$module" "$path" 2>/dev/null || continue
      import_add_file UNKNOWN "$path" "content-reference"
    done < <(find "$root" -xdev -type f -size -1024k -print0)
  done
}

import_scan_likely() {
  local module="$1" root theme
  for root in "$WHMCS_ROOT/assets/$module" "$WHMCS_ROOT/templates/$module"; do
    case "$root" in
      "$WHMCS_ROOT/assets/"*) theme=ASSET ;;
      *) theme=TEMPLATE ;;
    esac
    import_add_tree LIKELY "$root" "auxiliary-module-directory" "$theme"
  done

  shopt -s nullglob
  for root in "$WHMCS_ROOT/templates"/*/"$module"; do
    import_add_tree LIKELY "$root" "nested-template-directory" TEMPLATE
  done
  shopt -u nullglob

  for root in "$WHMCS_ROOT/modules" "$WHMCS_ROOT/includes/hooks" "$WHMCS_ROOT/crons" "$WHMCS_ROOT/assets" "$WHMCS_ROOT/templates"; do
    import_scan_likely_tree "$module" "$root"
  done
  import_scan_content_references "$module"
}

import_scan_module() {
  local module="$1"
  validate_module_id "$module"
  import_reset_scan
  import_scan_confirmed "$module"
  import_scan_likely "$module"
}

import_sorted_paths() {
  ((${#IMPORT_CLASS[@]} > 0)) || return 0
  printf '%s\n' "${!IMPORT_CLASS[@]}" | LC_ALL=C sort
}

import_sorted_unsafe_paths() {
  ((${#IMPORT_UNSAFE_REASON[@]} > 0)) || return 0
  printf '%s\n' "${!IMPORT_UNSAFE_REASON[@]}" | LC_ALL=C sort
}

import_print_scan() {
  local module="$1" path confirmed=0 likely=0 unknown_class=0 source=0 encoded=0 unknown_php=0 assets=0 secret=0 unsafe=0
  while IFS= read -r path; do
    [[ -n "$path" ]] || continue
    case "${IMPORT_CLASS[$path]}" in
      CONFIRMED) confirmed=$((confirmed + 1)) ;;
      LIKELY) likely=$((likely + 1)) ;;
      UNKNOWN) unknown_class=$((unknown_class + 1)) ;;
    esac
    case "${IMPORT_KIND[$path]}" in
      SOURCE) source=$((source + 1)) ;;
      IONCUBE) encoded=$((encoded + 1)) ;;
      UNKNOWN_PHP) unknown_php=$((unknown_php + 1)) ;;
      ASSET) assets=$((assets + 1)) ;;
    esac
    [[ "${IMPORT_SECRET[$path]}" != yes ]] || secret=$((secret + 1))
  done < <(import_sorted_paths)
  unsafe=${#IMPORT_UNSAFE_REASON[@]}

  echo "Module:        $module"
  echo "Target:        $TARGET_NAME"
  echo "WHMCS root:    $WHMCS_ROOT"
  echo "Confirmed:     $confirmed"
  echo "Likely:        $likely"
  echo "Unknown:       $unknown_class"
  echo "Source PHP:    $source"
  echo "ionCube PHP:   $encoded"
  echo "Unknown PHP:   $unknown_php"
  echo "Assets:        $assets"
  echo "Secret-risk:   $secret"
  echo "Unsafe:        $unsafe"
  echo
  printf '%-10s %-12s %-7s %-20s %s\n' CLASS KIND SECRET COMPONENT PATH
  while IFS= read -r path; do
    [[ -n "$path" ]] || continue
    printf '%-10s %-12s %-7s %-20s %s\n' \
      "${IMPORT_CLASS[$path]}" "${IMPORT_KIND[$path]}" "${IMPORT_SECRET[$path]}" \
      "${IMPORT_COMPONENT[$path]}" "$path"
  done < <(import_sorted_paths)

  if (( unsafe > 0 )); then
    echo
    echo "Unsafe entries (create will refuse until these are removed or replaced):"
    while IFS= read -r path; do
      [[ -n "$path" ]] || continue
      printf '  %-10s %-24s %s\n' "${IMPORT_UNSAFE_CLASS[$path]}" "${IMPORT_UNSAFE_REASON[$path]}" "$path"
    done < <(import_sorted_unsafe_paths)
  fi
}

import_add_explicit_paths() {
  local relative path
  for relative in "${IMPORT_EXPLICIT_PATHS[@]:-}"; do
    [[ -n "$relative" ]] || continue
    import_relative_is_safe "$relative" || fail "unsafe explicit import path: $relative"
    path="$WHMCS_ROOT/$relative"
    [[ -e "$path" || -L "$path" ]] || fail "explicit import path not found: $relative"
    if [[ -L "$path" ]]; then
      import_record_unsafe CONFIRMED "$path" symlink
    elif [[ -f "$path" ]]; then
      import_add_file CONFIRMED "$path" explicit-path EXPLICIT
    elif [[ -d "$path" ]]; then
      import_add_tree CONFIRMED "$path" explicit-path EXPLICIT
    else
      import_record_unsafe CONFIRMED "$path" special-entry
    fi
  done
}

import_parse_options() {
  IMPORT_INCLUDE_LIKELY=0
  IMPORT_INCLUDE_UNKNOWN=0
  IMPORT_INCLUDE_ENCODED=0
  IMPORT_INCLUDE_SECRET_RISK=0
  IMPORT_INCLUDE_UNKNOWN_PHP=0
  IMPORT_OUTPUT=''
  IMPORT_VERSION='0.1.0'
  IMPORT_EXPLICIT_PATHS=()
  while (($#)); do
    case "$1" in
      --include-likely) IMPORT_INCLUDE_LIKELY=1; shift ;;
      --include-unknown) IMPORT_INCLUDE_UNKNOWN=1; shift ;;
      --include-encoded) IMPORT_INCLUDE_ENCODED=1; shift ;;
      --include-secret-risk) IMPORT_INCLUDE_SECRET_RISK=1; shift ;;
      --include-unknown-php) IMPORT_INCLUDE_UNKNOWN_PHP=1; shift ;;
      --include-path)
        [[ $# -ge 2 && -n "${2:-}" ]] || fail "--include-path requires a WHMCS-root-relative path"
        import_relative_is_safe "$2" || fail "unsafe explicit import path: $2"
        IMPORT_EXPLICIT_PATHS+=("$2"); shift 2 ;;
      --output)
        [[ $# -ge 2 && -n "${2:-}" ]] || fail "--output requires an absolute path"
        IMPORT_OUTPUT="$2"; shift 2 ;;
      --version)
        [[ $# -ge 2 && -n "${2:-}" ]] || fail "--version requires a SemVer value"
        IMPORT_VERSION="$2"; shift 2 ;;
      *) fail "unknown import option: $1" ;;
    esac
  done
  [[ -z "$IMPORT_OUTPUT" || "$IMPORT_OUTPUT" == /* ]] || fail "import output must be an absolute path"
  semver_is_valid "$IMPORT_VERSION" || fail "import version must be SemVer X.Y.Z or X.Y.Z-prerelease"
}

import_decision() {
  local path="$1"
  if [[ "${IMPORT_CLASS[$path]}" == LIKELY && "$IMPORT_INCLUDE_LIKELY" != 1 ]]; then echo SKIP_LIKELY; return; fi
  if [[ "${IMPORT_CLASS[$path]}" == UNKNOWN && "$IMPORT_INCLUDE_UNKNOWN" != 1 ]]; then echo SKIP_UNKNOWN; return; fi
  if [[ "${IMPORT_KIND[$path]}" == IONCUBE && "$IMPORT_INCLUDE_ENCODED" != 1 ]]; then echo SKIP_IONCUBE; return; fi
  if [[ "${IMPORT_KIND[$path]}" == UNKNOWN_PHP && "$IMPORT_INCLUDE_UNKNOWN_PHP" != 1 ]]; then echo SKIP_UNKNOWN_PHP; return; fi
  if [[ "${IMPORT_SECRET[$path]}" == yes && "$IMPORT_INCLUDE_SECRET_RISK" != 1 ]]; then echo SKIP_SECRET_RISK; return; fi
  echo INCLUDE
}

import_print_plan() {
  local module="$1" path decision selected=0 skipped=0
  echo "Module:          $module"
  echo "Target:          $TARGET_NAME"
  echo "Version:         $IMPORT_VERSION"
  echo "Include likely:  $IMPORT_INCLUDE_LIKELY"
  echo "Include unknown: $IMPORT_INCLUDE_UNKNOWN"
  echo "Include encoded: $IMPORT_INCLUDE_ENCODED"
  echo "Include secrets: $IMPORT_INCLUDE_SECRET_RISK"
  echo "Include unknown PHP: $IMPORT_INCLUDE_UNKNOWN_PHP"
  echo
  printf '%-18s %-10s %-12s %-7s %s\n' DECISION CLASS KIND SECRET PATH
  while IFS= read -r path; do
    [[ -n "$path" ]] || continue
    decision="$(import_decision "$path")"
    if [[ "$decision" == INCLUDE ]]; then selected=$((selected + 1)); else skipped=$((skipped + 1)); fi
    printf '%-18s %-10s %-12s %-7s %s\n' "$decision" "${IMPORT_CLASS[$path]}" "${IMPORT_KIND[$path]}" "${IMPORT_SECRET[$path]}" "$path"
  done < <(import_sorted_paths)
  echo
  echo "Will import: $selected"
  echo "Will skip:   $skipped"
  echo "Unsafe:      ${#IMPORT_UNSAFE_REASON[@]}"
  if ((${#IMPORT_UNSAFE_REASON[@]} > 0)); then
    echo "Create status: BLOCKED by unsafe entries"
  elif (( selected == 0 )); then
    echo "Create status: BLOCKED (no selected files)"
  else
    echo "Create status: READY"
  fi
}

import_output_path() {
  local module="$1" requested="$2" output parent base
  if [[ -n "$requested" ]]; then output="$requested"; else output="$REPOS_ROOT/$module"; fi
  [[ "$output" == /* ]] || fail "import output must be absolute: $output"
  [[ ! -e "$output" && ! -L "$output" ]] || fail "import output already exists: $output"
  parent="$(dirname "$output")"
  [[ -d "$parent" && ! -L "$parent" ]] || fail "import output parent is not a regular directory: $parent"
  secure_root_owned_path "$parent" "import output parent"
  parent="$(cd "$parent" && pwd -P)"
  base="$(basename "$output")"
  [[ "$base" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$ && "$base" != '.' && "$base" != '..' ]] || fail "unsafe import output name: $base"
  output="$parent/$base"
  [[ "$output" != "$WHMCS_ROOT" && "$output" != "$WHMCS_ROOT/"* ]] || fail "refusing to create import repository inside WHMCS_ROOT"
  if [[ "$parent" == "$REPOS_ROOT" && "$base" != "$module" ]]; then
    fail "repositories directly under REPOS_ROOT must use the module id as directory name: $module"
  fi
  printf '%s\n' "$output"
}

import_write_manifest() {
  local stage="$1" module="$2"
  cat > "$stage/whmcs-module.json" <<EOF_MANIFEST
{
  "schema": 1,
  "id": "$module",
  "name": "Imported $module",
  "release": {
    "version_file": "VERSION",
    "tag_prefix": "v"
  },
  "deploy": {
    "files": "deploy-files.txt",
    "remove_stale": true
  }
}
EOF_MANIFEST
  chmod 0644 "$stage/whmcs-module.json"
}

import_write_report() {
  local stage="$1" module="$2" path decision
  {
    echo "# whmcsmod import report"
    echo
    echo "- Module: \`$module\`"
    echo "- Target: \`$TARGET_NAME\`"
    echo "- Initial version: \`$IMPORT_VERSION\`"
    echo "- Source policy: production WHMCS was read-only; no source file was modified."
    echo "- Git policy: local repository created only; no remote was configured and nothing was pushed."
    echo
    echo "## Selection"
    echo
    echo '```text'
    printf '%-18s %-10s %-12s %-7s %s\n' DECISION CLASS KIND SECRET PATH
    while IFS= read -r path; do
      [[ -n "$path" ]] || continue
      decision="$(import_decision "$path")"
      printf '%-18s %-10s %-12s %-7s %s\n' "$decision" "${IMPORT_CLASS[$path]}" "${IMPORT_KIND[$path]}" "${IMPORT_SECRET[$path]}" "$path"
    done < <(import_sorted_paths)
    echo '```'
  } > "$stage/IMPORT-REPORT.md"
  chmod 0644 "$stage/IMPORT-REPORT.md"
}

import_create_repository() {
  local module="$1" output stage parent path decision target selected=0
  local -a selected_paths=()
  ((${#IMPORT_UNSAFE_REASON[@]} == 0)) || fail "import create refused: scan found unsafe/symlinked entries; run 'whmcsmod import scan $module'"

  while IFS= read -r path; do
    [[ -n "$path" ]] || continue
    decision="$(import_decision "$path")"
    [[ "$decision" == INCLUDE ]] || continue
    selected_paths+=("$path")
  done < <(import_sorted_paths)
  selected=${#selected_paths[@]}
  (( selected > 0 )) || fail "import create has no selected files; inspect the plan or enable an explicit include option"

  output="$(import_output_path "$module" "$IMPORT_OUTPUT")"
  parent="$(dirname "$output")"
  stage="$(mktemp -d "$parent/.whmcsmod-import-${module}.XXXXXX")"
  IMPORT_STAGE_DIR="$stage"
  import_create_cleanup() {
    local code=$?
    trap - EXIT
    set +e
    [[ -z "${IMPORT_STAGE_DIR:-}" ]] || rm -rf -- "$IMPORT_STAGE_DIR"
    exit "$code"
  }
  trap import_create_cleanup EXIT

  for path in "${selected_paths[@]}"; do
    import_relative_is_safe "$path" || fail "unsafe selected import path: $path"
    [[ -f "$WHMCS_ROOT/$path" && ! -L "$WHMCS_ROOT/$path" ]] || fail "selected source changed or became unsafe during import: $path"
    target="$stage/$path"
    install -d -m 0755 "$(dirname "$target")"
    install -m 0644 "$WHMCS_ROOT/$path" "$target"
    [[ -f "$target" && ! -L "$target" ]] || fail "imported target is not a regular file: $path"
  done

  printf '%s\n' "$IMPORT_VERSION" > "$stage/VERSION"
  chmod 0644 "$stage/VERSION"
  printf '%s\n' "${selected_paths[@]}" | LC_ALL=C sort -u > "$stage/deploy-files.txt"
  chmod 0644 "$stage/deploy-files.txt"
  import_write_manifest "$stage" "$module"
  import_write_report "$stage" "$module"
  cat > "$stage/.gitignore" <<'EOF_GITIGNORE'
.DS_Store
*.zip
*.zip.sha256
*.zip.json
EOF_GITIGNORE
  chmod 0644 "$stage/.gitignore"

  manifest_validate "$stage/whmcs-module.json" "$stage"
  need_cmd git
  git -C "$stage" init -q -b main
  secure_root_owned_path "$stage" "import staging repository"
  [[ -d "$stage/.git" && ! -L "$stage/.git" ]] || fail "unable to initialize imported Git repository"

  mv -- "$stage" "$output"
  IMPORT_STAGE_DIR=''
  trap - EXIT

  echo "Module:     $module"
  echo "Target:     $TARGET_NAME"
  echo "Version:    $IMPORT_VERSION"
  echo "Files:      $selected"
  echo "Repository: $output"
  echo "Git remote: none"
  echo "Git commit: none"
  echo
  echo "Review IMPORT-REPORT.md and deploy-files.txt before staging or committing files."
  if [[ "$output" == "$REPOS_ROOT/$module" ]]; then
    echo "The repository is now discoverable by whmcsmod, but it has no signed release tag yet."
  else
    echo "Custom output is outside the managed module slot; move/recreate it as $REPOS_ROOT/$module when ready for whmcsmod management."
  fi
}

cmd_import_scan() {
  local module="$1"
  need_cmd find; need_cmd grep; need_cmd head; need_cmd basename
  import_scan_module "$module"
  import_print_scan "$module"
}

cmd_import_plan() {
  local module="$1"; shift
  need_cmd find; need_cmd grep; need_cmd head; need_cmd basename
  import_parse_options "$@"
  import_scan_module "$module"
  import_add_explicit_paths
  import_print_plan "$module"
}

cmd_import_create() {
  local module="$1"; shift
  need_cmd find; need_cmd grep; need_cmd head; need_cmd basename; need_cmd git
  import_parse_options "$@"
  import_scan_module "$module"
  import_add_explicit_paths
  import_print_plan "$module"
  echo
  import_create_repository "$module"
}
