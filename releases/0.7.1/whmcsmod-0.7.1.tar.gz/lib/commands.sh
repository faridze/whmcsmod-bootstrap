# User-facing commands.
cmd_adopt() {
  local module="$1" requested="${2:-latest}"
  validate_module_id "$module"
  local state_dir
  state_dir="$(state_dir_for "$module")"
  [[ ! -f "$state_dir/current-version" ]] || fail "$module is already managed"

  STAGE_REPO="" STAGE_DIR="" STAGE_SOURCE="" STAGE_REF="" STAGE_COMMIT="" HEALTHCHECK_TEMP=""
  DEPLOY_TEMPS=()
  stage_release "$module" "$requested"
  on_adopt_exit() {
    local code=$?
    trap - EXIT
    set +e
    cleanup_stage
    exit "$code"
  }
  trap on_adopt_exit EXIT

  local manifest="$STAGE_SOURCE/whmcs-module.json"
  manifest_validate "$manifest" "$STAGE_SOURCE"
  local staged_id version relative source_hash target_hash errors=0
  staged_id="$(manifest_get "$manifest" id)"
  [[ "$staged_id" == "$module" ]] || fail "manifest id '$staged_id' does not match repository directory '$module'"
  version="$(check_release_consistency "$STAGE_SOURCE" "$manifest" "$STAGE_REF")"
  run_validate_hook "$STAGE_SOURCE" "$manifest"
  load_deploy_files "$STAGE_SOURCE" "$manifest"
  check_file_collisions "$module"

  for relative in "${DEPLOY_FILES[@]}"; do
    if [[ ! -f "$WHMCS_ROOT/$relative" ]]; then
      echo "$module: MISSING $relative" >&2
      errors=$((errors + 1))
      continue
    fi
    source_hash="$(sha256sum "$STAGE_SOURCE/$relative" | awk '{print $1}')"
    target_hash="$(sha256sum "$WHMCS_ROOT/$relative" | awk '{print $1}')"
    if [[ "$source_hash" != "$target_hash" ]]; then
      echo "$module: CHANGED $relative" >&2
      errors=$((errors + 1))
    fi
  done
  if (( errors != 0 )); then
    fail "$module cannot be adopted as $STAGE_REF because $errors managed file(s) do not match the signed release"
  fi

  run_healthcheck "$STAGE_SOURCE" "$manifest" check
  write_state "$module" "$STAGE_REF" "$version" "$STAGE_COMMIT"
  echo "$module: adopted existing deployment as $STAGE_REF"
  cleanup_stage
  trap - EXIT
}

cmd_list() {
  printf '%-20s %-16s %-16s\n' MODULE INSTALLED LOCAL_TAG
  local repo module manifest installed latest
  shopt -s nullglob
  for repo in "$REPOS_ROOT"/*; do
    [[ -d "$repo/.git" && -f "$repo/whmcs-module.json" ]] || continue
    module="$(basename "$repo")"
    manifest="$repo/whmcs-module.json"
    installed="$(cat "$(state_dir_for "$module")/current-version" 2>/dev/null || echo '-')"
    latest="$(latest_tag "$repo" "$manifest" 2>/dev/null || true)"
    [[ -n "$latest" ]] || latest="-"
    printf '%-20s %-16s %-16s\n' "$module" "$installed" "$latest"
  done
  shopt -u nullglob
}

cmd_status() {
  local module="$1" repo state manifest latest
  repo="$(repo_for "$module")"
  state="$(state_dir_for "$module")"
  manifest="$(manifest_from_worktree "$repo")"
  latest="$(latest_tag "$repo" "$manifest" 2>/dev/null || true)"
  echo "Module:    $module"
  echo "Installed: $(cat "$state/current-version" 2>/dev/null || echo not-installed)"
  echo "Ref:       $(cat "$state/current-ref" 2>/dev/null || echo -)"
  echo "Local tag: ${latest:--}"
  echo "Repo:      $repo"
  echo "WHMCS:     $WHMCS_ROOT"
}

cmd_check_one() {
  local module="$1" repo manifest latest current
  repo="$(repo_for "$module")"
  secure_repo "$repo"
  fetch_tags "$repo"
  manifest="$(manifest_from_worktree "$repo")"
  latest="$(latest_tag "$repo" "$manifest")"
  current="$(cat "$(state_dir_for "$module")/current-ref" 2>/dev/null || echo not-installed)"
  echo "$module: installed=$current available=${latest:-none}"
}

cmd_check_all() {
  local repo
  shopt -s nullglob
  for repo in "$REPOS_ROOT"/*; do
    [[ -d "$repo/.git" && -f "$repo/whmcs-module.json" ]] || continue
    cmd_check_one "$(basename "$repo")"
  done
  shopt -u nullglob
}

cmd_verify() {
  local module="$1" state hash relative expected actual errors=0
  state="$(state_dir_for "$module")"
  [[ -f "$state/current-files.sha256" ]] || fail "$module has no installed inventory"
  while read -r hash relative; do
    [[ -n "$hash" && -n "$relative" ]] || continue
    expected="$hash"
    if [[ ! -f "$WHMCS_ROOT/$relative" ]]; then
      echo "MISSING  $relative"
      errors=$((errors+1))
      continue
    fi
    actual="$(sha256sum "$WHMCS_ROOT/$relative" | awk '{print $1}')"
    if [[ "$actual" != "$expected" ]]; then
      echo "CHANGED  $relative"
      errors=$((errors+1))
    fi
  done < "$state/current-files.sha256"
  if ((errors == 0)); then echo "$module: deployed files verified"; else fail "$module: $errors file(s) drifted"; fi
}

cmd_history() {
  local module="$1" root backup
  root="$(backup_dir_for "$module")"
  [[ -d "$root" ]] || { echo "$module: no backups"; return 0; }
  shopt -s nullglob
  for backup in "$root"/*; do
    [[ -d "$backup" ]] || continue
    printf '%s  ' "$(basename "$backup")"
    tr '\n' ' ' < "$backup/meta" 2>/dev/null || true
    echo
  done | sort -r
  shopt -u nullglob
}

cmd_rollback() {
  local module="$1" requested="${2:-last}" state root backup
  state="$(state_dir_for "$module")"
  root="$(backup_dir_for "$module")"
  if [[ "$requested" == "last" ]]; then
    [[ -f "$state/last-backup" ]] || fail "$module has no recorded last backup"
    backup="$(cat "$state/last-backup")"
  else
    [[ "$requested" =~ ^[A-Za-z0-9._:-]+$ ]] || fail "invalid backup id"
    backup="$root/$requested"
  fi
  [[ "$backup" == "$root/"* ]] || fail "backup path escapes module backup root"
  echo "$module: restoring $(basename "$backup")"
  restore_backup "$module" "$backup"
  date -Is > "$STATE_ROOT/modules/$module/last-rollback" 2>/dev/null || true
  echo "$module: code rollback completed"
  warn "database migrations are not reversed"
}

cmd_doctor() {
  need_cmd git; need_cmd gpg; need_cmd ssh; need_cmd tar; need_cmd flock; need_cmd sha256sum; need_cmd runuser
  echo "Config:     OK ($CONFIG_FILE)"
  echo "WHMCS:      OK ($WHMCS_ROOT)"
  echo "Runtime:    OK ($WHMCS_RUN_USER)"
  echo "PHP:        $($PHP_BIN -r 'echo PHP_VERSION;')"
  echo "Composer:   ${COMPOSER_BIN:-disabled}"
  echo "Repos:      $REPOS_ROOT"
  echo "State:      $STATE_ROOT"
  echo "Backups:    $BACKUP_ROOT"
  local fingerprint home gpg_home
  fingerprint="${TRUSTED_TAG_SIGNING_FINGERPRINT//[[:space:]]/}"
  fingerprint="${fingerprint^^}"
  if [[ ! "$fingerprint" =~ ^[A-F0-9]{40,64}$ ]]; then
    echo "Signing key: NOT CONFIGURED"
    return 1
  fi
  home="$(run_home)"
  check_secure_git_home "$home"
  gpg_home="$home/.gnupg"
  local fingerprints
  if [[ ! -d "$gpg_home" ]]; then
    echo "Signing key: fingerprint configured but public key is missing from $gpg_home"
    return 1
  fi
  fingerprints="$(GNUPGHOME="$gpg_home" gpg --batch --with-colons --list-keys 2>/dev/null \
    | awk -F: '$1 == "fpr" {print toupper($10)}')" || {
      echo "Signing key: unable to read $gpg_home"
      return 1
    }
  if ! grep -Fx "$fingerprint" <<< "$fingerprints" >/dev/null; then
    echo "Signing key: fingerprint configured but public key is missing from $gpg_home"
    return 1
  fi
  echo "Signing key: configured and present"
}

validate_backup_id() {
  local backup_id="$1"
  [[ "$backup_id" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$ ]] \
    || fail "invalid backup id: $backup_id"
}

preflight_backup_policy() {
  if backup_auto_prune_enabled; then
    backup_keep_default >/dev/null
  fi
}

cmd_backup_show() {
  local module="$1" backup_id="$2" root backup state last=no complete=yes required
  local created target_ref previous_version previous_ref meta_module relative captured=0 absent=0
  local files_archive=missing state_archive=missing
  local -a missing_parts=()

  validate_module_id "$module"
  validate_backup_id "$backup_id"
  need_cmd tar
  root="$(backup_dir_for "$module")"
  [[ -d "$root" && ! -L "$root" ]] || fail "backup directory not found for module $module: $root"
  secure_root_owned_path "$root" "module backup directory"
  root="$(cd "$root" && pwd -P)"
  backup="$root/$backup_id"
  [[ -d "$backup" && ! -L "$backup" ]] || fail "backup not found: $module/$backup_id"
  [[ "$(dirname "$backup")" == "$root" ]] || fail "backup path escapes module backup root"
  secure_root_owned_path "$backup" "backup"

  for required in meta files.txt present.txt files.tgz state.tgz; do
    if [[ ! -f "$backup/$required" || -L "$backup/$required" ]]; then
      complete=no
      missing_parts+=("$required")
    fi
  done

  if [[ -f "$backup/files.tgz" && ! -L "$backup/files.tgz" ]]; then
    if tar -tzf "$backup/files.tgz" >/dev/null 2>&1; then files_archive=readable; else files_archive=unreadable; complete=no; fi
  fi
  if [[ -f "$backup/state.tgz" && ! -L "$backup/state.tgz" ]]; then
    if tar -tzf "$backup/state.tgz" >/dev/null 2>&1; then state_archive=readable; else state_archive=unreadable; complete=no; fi
  fi

  created="$(backup_meta_value "$backup" created 2>/dev/null || echo '-')"
  target_ref="$(backup_meta_value "$backup" target_ref 2>/dev/null || echo '-')"
  previous_version="$(backup_meta_value "$backup" previous_version 2>/dev/null || echo '-')"
  previous_ref="$(backup_meta_value "$backup" previous_ref 2>/dev/null || echo '-')"
  meta_module="$(backup_meta_value "$backup" module 2>/dev/null || echo '-')"
  if [[ "$meta_module" != '-' && "$meta_module" != "$module" ]]; then
    warn "backup metadata module '$meta_module' does not match requested module '$module'"
    complete=no
  fi

  state="$(state_dir_for "$module")"
  if [[ -f "$state/last-backup" && ! -L "$state/last-backup" ]]; then
    [[ "$(cat "$state/last-backup")" != "$backup" ]] || last=yes
  fi

  if [[ -f "$backup/present.txt" && ! -L "$backup/present.txt" ]]; then
    while IFS= read -r relative || [[ -n "$relative" ]]; do
      [[ -n "$relative" ]] || continue
      safe_relative "$relative"
      captured=$((captured + 1))
    done < "$backup/present.txt"
  fi
  if [[ -f "$backup/files.txt" && ! -L "$backup/files.txt" ]]; then
    while IFS= read -r relative || [[ -n "$relative" ]]; do
      [[ -n "$relative" ]] || continue
      safe_relative "$relative"
      if [[ ! -f "$backup/present.txt" || -L "$backup/present.txt" ]] || ! grep -Fxq "$relative" "$backup/present.txt"; then
        absent=$((absent + 1))
      fi
    done < "$backup/files.txt"
  fi

  echo "Module:           $module"
  echo "Backup ID:        $backup_id"
  echo "Target:           $TARGET_NAME"
  echo "Path:             $backup"
  echo "Created:          $created"
  echo "Previous version: $previous_version"
  echo "Previous ref:     $previous_ref"
  echo "Target ref:       $target_ref"
  echo "Recorded last:    $last"
  echo "Complete:         $complete"
  echo "Files archive:    $files_archive"
  echo "State archive:    $state_archive"
  if ((${#missing_parts[@]} > 0)); then printf 'Missing parts:    %s\n' "${missing_parts[*]}"; fi
  echo "Captured files:   $captured"
  echo "Restore-as-absent: $absent"

  echo
  echo "Files captured in backup:"
  if [[ -f "$backup/present.txt" && ! -L "$backup/present.txt" && -s "$backup/present.txt" ]]; then
    while IFS= read -r relative || [[ -n "$relative" ]]; do
      [[ -n "$relative" ]] || continue
      safe_relative "$relative"
      printf '  %s\n' "$relative"
    done < "$backup/present.txt"
  else
    echo "  (none or inventory unavailable)"
  fi

  echo
  echo "Paths restored as absent (deleted if present during rollback):"
  if [[ -f "$backup/files.txt" && ! -L "$backup/files.txt" ]]; then
    local printed=0
    while IFS= read -r relative || [[ -n "$relative" ]]; do
      [[ -n "$relative" ]] || continue
      safe_relative "$relative"
      if [[ ! -f "$backup/present.txt" || -L "$backup/present.txt" ]] || ! grep -Fxq "$relative" "$backup/present.txt"; then
        printf '  %s\n' "$relative"
        printed=1
      fi
    done < "$backup/files.txt"
    (( printed == 1 )) || echo "  (none)"
  else
    echo "  (inventory unavailable)"
  fi
}

package_default_output_dir() {
  [[ "${MANAGER_STATE_ROOT:-}" == /* ]] || fail "global manager state root is unavailable"
  printf '%s\n' "$MANAGER_STATE_ROOT/packages"
}

package_output_dir() {
  local requested="${1:-}" output
  if [[ -n "$requested" ]]; then
    [[ "$requested" == /* ]] || fail "package output directory must be absolute: $requested"
    output="$requested"
  else
    output="$(package_default_output_dir)"
  fi
  if [[ ! -e "$output" ]]; then install -d -m 0700 "$output"; fi
  [[ -d "$output" && ! -L "$output" ]] || fail "invalid package output directory: $output"
  secure_root_owned_path "$output" "package output directory"
  (cd "$output" && pwd -P)
}

package_load_files() {
  local source="$1" manifest="$2" list_file relative existing
  list_file="$(manifest_get "$manifest" deploy.files)"
  safe_relative "$list_file"
  [[ -f "$source/$list_file" && ! -L "$source/$list_file" ]] || fail "deploy file list missing: $list_file"
  PACKAGE_FILES=()
  while IFS= read -r relative || [[ -n "$relative" ]]; do
    relative="${relative%$'\r'}"
    [[ -n "$relative" ]] || continue
    [[ "$relative" != \#* ]] || continue
    safe_relative "$relative"
    [[ -f "$source/$relative" && ! -L "$source/$relative" ]] || fail "package source missing or symlinked: $relative"
    for existing in "${PACKAGE_FILES[@]:-}"; do
      [[ "$existing" != "$relative" ]] || fail "duplicate package path: $relative"
    done
    PACKAGE_FILES+=("$relative")
  done < "$source/$list_file"
  ((${#PACKAGE_FILES[@]} > 0)) || fail "package deploy file list is empty"
}

package_copy_files() {
  local source="$1" payload="$2" relative target
  for relative in "${PACKAGE_FILES[@]}"; do
    safe_relative "$relative"
    target="$payload/$relative"
    install -d -m 0755 "$(dirname "$target")"
    [[ ! -e "$target" && ! -L "$target" ]] || fail "duplicate package payload path: $relative"
    install -m 0644 "$source/$relative" "$target"
  done
}

package_run_composer() {
  local manifest="$1" payload="$2" path composer_json
  while IFS= read -r path || [[ -n "$path" ]]; do
    [[ -n "$path" ]] || continue
    [[ -n "$COMPOSER_BIN" ]] || fail "module package requires Composer but COMPOSER_BIN is empty"
    safe_relative "$path"
    composer_json="$payload/$path/composer.json"
    [[ -f "$composer_json" && ! -L "$composer_json" ]] || fail "package composer.json missing at $path; include it in deploy.files"
    [[ -d "$payload/$path" && ! -L "$payload/$path" ]] || fail "invalid package Composer path: $path"
    COMPOSER_ALLOW_SUPERUSER=1 "$COMPOSER_BIN" install \
      --working-dir="$payload/$path" --no-dev --prefer-dist \
      --optimize-autoloader --no-interaction
  done < <("$PHP_BIN" "$MANIFEST_TOOL" composer-paths "$manifest")
}

package_validate_payload() {
  local payload="$1" bad
  bad="$(find "$payload" -mindepth 1 \( -type l -o \( ! -type f ! -type d \) \) -print -quit)"
  [[ -z "$bad" ]] || fail "package payload contains a symlink or special entry: ${bad#$payload/}"
}

package_normalize_timestamps() {
  local payload="$1" epoch="$2"
  [[ "$epoch" =~ ^[0-9]+$ ]] || fail "invalid package source timestamp"
  find "$payload" -exec touch -h -d "@$epoch" {} +
}

package_write_metadata() {
  local path="$1" module="$2" version="$3" ref="$4" commit="$5" archive_name="$6" sha="$7" file_count="$8" composer_used="$9"
  cat > "$path" <<EOF_METADATA
{
  "schema": 1,
  "module": "$module",
  "version": "$version",
  "release_ref": "$ref",
  "release_commit": "$commit",
  "archive": "$archive_name",
  "sha256": "$sha",
  "files": $file_count,
  "composer_vendored": $composer_used,
  "manual_install": "Extract the ZIP into the WHMCS root. whmcsmod migration and healthcheck hooks are not executed by manual extraction."
}
EOF_METADATA
  chmod 0600 "$path"
}

cmd_package() {
  local module="$1" requested="${2:-latest}" requested_output="${3:-}"
  local manifest staged_id version output payload archive archive_tmp sha epoch file_count composer_used=false
  local metadata_tmp sha_tmp archive_name

  validate_module_id "$module"
  need_cmd git; need_cmd gpg; need_cmd ssh; need_cmd zip; need_cmd sha256sum; need_cmd touch

  STAGE_REPO="" STAGE_DIR="" STAGE_SOURCE="" STAGE_REF="" STAGE_COMMIT="" HEALTHCHECK_TEMP=""
  DEPLOY_TEMPS=()
  stage_release "$module" "$requested"
  on_package_exit() {
    local code=$?
    trap - EXIT
    set +e
    cleanup_stage
    exit "$code"
  }
  trap on_package_exit EXIT

  manifest="$STAGE_SOURCE/whmcs-module.json"
  manifest_validate "$manifest" "$STAGE_SOURCE"
  staged_id="$(manifest_get "$manifest" id)"
  [[ "$staged_id" == "$module" ]] || fail "manifest id '$staged_id' does not match repository directory '$module'"
  version="$(check_release_consistency "$STAGE_SOURCE" "$manifest" "$STAGE_REF")"
  package_load_files "$STAGE_SOURCE" "$manifest"

  output="$(package_output_dir "$requested_output")"
  archive_name="$module-$version.zip"
  archive="$output/$archive_name"
  [[ ! -e "$archive" && ! -L "$archive" ]] || fail "package already exists: $archive"
  [[ ! -e "$archive.sha256" && ! -L "$archive.sha256" ]] || fail "package checksum already exists: $archive.sha256"
  [[ ! -e "$archive.json" && ! -L "$archive.json" ]] || fail "package metadata already exists: $archive.json"

  payload="$STAGE_DIR/payload"
  install -d -m 0700 "$payload"
  package_copy_files "$STAGE_SOURCE" "$payload"
  if "$PHP_BIN" "$MANIFEST_TOOL" composer-paths "$manifest" | grep -q .; then
    composer_used=true
    package_run_composer "$manifest" "$payload"
  fi
  package_validate_payload "$payload"

  epoch="$(git_repo "$STAGE_REPO" show -s --format=%ct "$STAGE_COMMIT")"
  package_normalize_timestamps "$payload" "$epoch"
  archive_tmp="$(mktemp "$output/.${archive_name}.XXXXXX")"
  rm -f -- "$archive_tmp"
  (
    cd "$payload"
    find . -type f -printf '%P\n' | LC_ALL=C sort | zip -X -q "$archive_tmp" -@
  )
  zip -T "$archive_tmp" >/dev/null
  chmod 0600 "$archive_tmp"
  sha="$(sha256sum "$archive_tmp" | awk '{print tolower($1)}')"
  [[ "$sha" =~ ^[a-f0-9]{64}$ ]] || fail "unable to calculate package SHA-256"
  file_count="$(find "$payload" -type f | wc -l | tr -d '[:space:]')"
  [[ "$file_count" =~ ^[0-9]+$ && "$file_count" -gt 0 ]] || fail "package payload is empty"

  metadata_tmp="$(mktemp "$output/.${archive_name}.json.XXXXXX")"
  package_write_metadata "$metadata_tmp" "$module" "$version" "$STAGE_REF" "$STAGE_COMMIT" "$archive_name" "$sha" "$file_count" "$composer_used"
  sha_tmp="$(mktemp "$output/.${archive_name}.sha256.XXXXXX")"
  printf '%s  %s\n' "$sha" "$archive_name" > "$sha_tmp"
  chmod 0600 "$sha_tmp"

  mv -- "$archive_tmp" "$archive"
  mv -- "$sha_tmp" "$archive.sha256"
  mv -- "$metadata_tmp" "$archive.json"

  echo "Module:    $module"
  echo "Release:   $STAGE_REF"
  echo "Version:   $version"
  echo "Commit:    $STAGE_COMMIT"
  echo "Files:     $file_count"
  echo "Composer:  $composer_used"
  echo "Package:   $archive"
  echo "SHA-256:   $sha"
  echo "Metadata:  $archive.json"
  echo "Checksum:  $archive.sha256"
  echo
  echo "Manual install: extract $archive_name into the target WHMCS root."
  echo "Note: manual extraction does not execute whmcsmod migration or healthcheck hooks."

  cleanup_stage
  trap - EXIT
}

usage() {
  cat <<'EOF_USAGE'
WHMCS Module Manager

Usage:
  whmcsmod version
  whmcsmod [--target NAME] list
  whmcsmod [--target NAME] status <module|--all>
  whmcsmod [--target NAME] check <module|--all>
  whmcsmod [--target NAME] plan <module> [latest|vX.Y.Z[-prerelease]]
  whmcsmod [--target NAME] plan --all
  whmcsmod [--target NAME] import scan <module>
  whmcsmod [--target NAME] import plan <module> [IMPORT_OPTIONS]
  whmcsmod [--target NAME] import create <module> [IMPORT_OPTIONS]
  whmcsmod [--target NAME] package <module> [latest|vX.Y.Z[-prerelease]] [OUTPUT_DIR]
  whmcsmod [--target NAME] install <module> [latest|vX.Y.Z[-prerelease]]
  whmcsmod [--target NAME] adopt <module> [latest|vX.Y.Z[-prerelease]]
  whmcsmod [--target NAME] takeover <module> <vX.Y.Z[-prerelease]> [--dry-run]
  whmcsmod [--target NAME] update <module> [latest|vX.Y.Z[-prerelease]] [--dry-run]
  whmcsmod [--target NAME] update --all [--dry-run]
  whmcsmod [--target NAME] verify <module>
  whmcsmod [--target NAME] history <module>
  whmcsmod [--target NAME] rollback <module> [last|BACKUP_ID]
  whmcsmod [--target NAME] backup list [module|--all]
  whmcsmod [--target NAME] backup show <module> <BACKUP_ID>
  whmcsmod [--target NAME] backup prune <module|--all> [--keep N]
  whmcsmod [--target NAME] doctor [--all]
  whmcsmod target list
  whmcsmod [--target NAME] target show
  whmcsmod target set-default <NAME>
  whmcsmod repo add <OWNER/REPO> [--manual]
  whmcsmod repo list
  whmcsmod repo status <module>
  whmcsmod repo refresh <module>
  whmcsmod repo audit [module|--all]
  whmcsmod repo remove <module> [--manual]
  whmcsmod self-update [--check|X.Y.Z]

--target NAME may appear anywhere in the command line. Without it, DEFAULT_TARGET is used.
--dry-run may appear anywhere but is supported only by takeover and update.
import scan is read-only. import plan is read-only. import create copies selected production module files into a new local Git repository and never changes WHMCS or pushes a remote.
Import defaults to confirmed source/assets only; likely paths, ionCube PHP, secret-risk files, and unknown PHP require explicit include flags.
package authenticates the signed release and creates a WHMCS-root-relative ZIP without modifying WHMCS, module state, or backups.
Package Composer dependencies are vendored into the ZIP when the module manifest declares Composer paths.
Manual extraction does not execute whmcsmod migration or healthcheck hooks.
plan and update --dry-run authenticate/stage the signed release but do not modify WHMCS files, module state, or backups.
Explicit prerelease tags are allowed; latest/check/update --all remain stable-only.
EOF_USAGE
}

whmcsmod_main() {
  REQUESTED_TARGET=""
  REQUESTED_DRY_RUN=0
  local -a args=()
  while (($#)); do
    case "$1" in
      --target)
        [[ $# -ge 2 && -n "${2:-}" ]] || { usage; exit 2; }
        [[ -z "$REQUESTED_TARGET" ]] || fail "--target specified more than once"
        REQUESTED_TARGET="$2"
        shift 2
        ;;
      --target=*)
        [[ -z "$REQUESTED_TARGET" ]] || fail "--target specified more than once"
        REQUESTED_TARGET="${1#--target=}"
        [[ -n "$REQUESTED_TARGET" ]] || { usage; exit 2; }
        shift
        ;;
      --dry-run)
        (( REQUESTED_DRY_RUN == 0 )) || fail "--dry-run specified more than once"
        REQUESTED_DRY_RUN=1
        shift
        ;;
      *) args+=("$1"); shift ;;
    esac
  done
  set -- "${args[@]}"

  local cmd="${1:-}"
  case "$cmd" in
    version|-V|--version)
      [[ $# -eq 1 && -z "$REQUESTED_TARGET" && "$REQUESTED_DRY_RUN" == 0 ]] || { usage; exit 2; }
      cmd_version
      return 0
      ;;
    -h|--help|help|'')
      [[ "$REQUESTED_DRY_RUN" == 0 ]] || { usage; exit 2; }
      usage
      return 0
      ;;
  esac

  require_root
  need_cmd stat; need_cmd find; need_cmd awk; need_cmd grep; need_cmd sort; need_cmd mktemp; need_cmd install; need_cmd getent
  load_config
  if (( REQUESTED_DRY_RUN == 1 )) && [[ "$cmd" != "takeover" && "$cmd" != "update" ]]; then
    fail "--dry-run is supported only by takeover and update"
  fi
  case "$cmd" in
    -h|--help|help|''|target|repo|self-update|version|-V|--version|backup|package|import) ;;
    *) echo "Target: $TARGET_NAME" ;;
  esac

  case "$cmd" in
    version|-V|--version) [[ $# -eq 1 ]] || { usage; exit 2; }; cmd_version ;;
    list) [[ $# -eq 1 ]] || { usage; exit 2; }; cmd_list ;;
    status)
      [[ $# -eq 2 ]] || { usage; exit 2; }
      if [[ "$2" == "--all" ]]; then cmd_status_all; else cmd_status "$2"; fi
      ;;
    check)
      [[ $# -eq 2 ]] || { usage; exit 2; }
      if [[ "$2" == "--all" ]]; then cmd_check_all; else cmd_check_one "$2"; fi
      ;;
    plan)
      [[ $# -ge 2 && $# -le 3 ]] || { usage; exit 2; }
      acquire_global_lock
      if [[ "$2" == "--all" ]]; then
        [[ $# -eq 2 ]] || { usage; exit 2; }
        plan_update_all
      else
        plan_update_one "$2" "${3:-latest}"
      fi
      ;;
    import)
      case "${2:-}" in
        scan)
          [[ $# -eq 3 ]] || { usage; exit 2; }
          cmd_import_scan "$3"
          ;;
        plan)
          [[ $# -ge 3 ]] || { usage; exit 2; }
          cmd_import_plan "$3" "${@:4}"
          ;;
        create)
          [[ $# -ge 3 ]] || { usage; exit 2; }
          acquire_global_lock
          cmd_import_create "$3" "${@:4}"
          ;;
        *) usage; exit 2 ;;
      esac
      ;;
    package)
      [[ $# -ge 2 && $# -le 4 ]] || { usage; exit 2; }
      acquire_global_lock
      cmd_package "$2" "${3:-latest}" "${4:-}"
      ;;
    install)
      [[ $# -ge 2 && $# -le 3 ]] || { usage; exit 2; }
      preflight_backup_policy
      acquire_global_lock; update_one "$2" "${3:-latest}" install; maybe_auto_prune_backups "$2"
      ;;
    adopt)
      [[ $# -ge 2 && $# -le 3 ]] || { usage; exit 2; }
      acquire_global_lock; cmd_adopt "$2" "${3:-latest}"
      ;;
    takeover)
      [[ $# -eq 3 ]] || { usage; exit 2; }
      if (( REQUESTED_DRY_RUN == 0 )); then preflight_backup_policy; acquire_global_lock; fi
      takeover_one "$2" "$3" "$REQUESTED_DRY_RUN"
      if (( REQUESTED_DRY_RUN == 0 )); then maybe_auto_prune_backups "$2"; fi
      ;;
    update)
      [[ $# -ge 2 && $# -le 3 ]] || { usage; exit 2; }
      if (( REQUESTED_DRY_RUN == 0 )); then preflight_backup_policy; fi
      acquire_global_lock
      if [[ "$2" == "--all" ]]; then
        [[ $# -eq 2 ]] || { usage; exit 2; }
        if (( REQUESTED_DRY_RUN == 1 )); then
          plan_update_all
        else
          local repo module
          shopt -s nullglob
          for repo in "$REPOS_ROOT"/*; do
            [[ -d "$repo/.git" && -f "$repo/whmcs-module.json" ]] || continue
            module="$(basename "$repo")"
            [[ -f "$(state_dir_for "$module")/current-version" ]] || continue
            update_one "$module" latest update
            maybe_auto_prune_backups "$module"
          done
          shopt -u nullglob
        fi
      else
        if (( REQUESTED_DRY_RUN == 1 )); then
          plan_update_one "$2" "${3:-latest}"
        else
          update_one "$2" "${3:-latest}" update
          maybe_auto_prune_backups "$2"
        fi
      fi
      ;;
    verify) [[ $# -eq 2 ]] || { usage; exit 2; }; cmd_verify "$2" ;;
    history) [[ $# -eq 2 ]] || { usage; exit 2; }; cmd_history "$2" ;;
    rollback)
      [[ $# -ge 2 && $# -le 3 ]] || { usage; exit 2; }
      acquire_global_lock; cmd_rollback "$2" "${3:-last}"
      ;;
    backup)
      case "${2:-}" in
        list)
          [[ $# -ge 2 && $# -le 3 ]] || { usage; exit 2; }
          cmd_backup_list "${3:---all}"
          ;;
        show)
          [[ $# -eq 4 ]] || { usage; exit 2; }
          cmd_backup_show "$3" "$4"
          ;;
        prune)
          [[ $# -ge 3 ]] || { usage; exit 2; }
          [[ "$3" == "--all" || "$3" != --* ]] || { usage; exit 2; }
          acquire_global_lock
          cmd_backup_prune "${@:3}"
          ;;
        *) usage; exit 2 ;;
      esac
      ;;
    doctor)
      [[ $# -ge 1 && $# -le 2 ]] || { usage; exit 2; }
      if [[ "${2:-}" == "--all" ]]; then cmd_doctor_all; elif [[ $# -eq 1 ]]; then cmd_doctor; else usage; exit 2; fi
      ;;
    target)
      case "${2:-}" in
        list) [[ $# -eq 2 ]] || { usage; exit 2; }; cmd_target_list ;;
        show) [[ $# -eq 2 ]] || { usage; exit 2; }; cmd_target_show ;;
        set-default) [[ $# -eq 3 ]] || { usage; exit 2; }; cmd_target_set_default "$3" ;;
        *) usage; exit 2 ;;
      esac
      ;;
    self-update)
      [[ $# -le 2 ]] || { usage; exit 2; }
      if [[ "${2:-}" != '--check' ]]; then acquire_global_lock; fi
      if [[ $# -eq 1 ]]; then cmd_self_update; else cmd_self_update "$2"; fi
      ;;
    repo)
      case "${2:-}" in
        add)
          [[ $# -ge 3 && $# -le 4 ]] || { usage; exit 2; }
          [[ $# -eq 3 || "$4" == "--manual" ]] || { usage; exit 2; }
          acquire_global_lock
          cmd_repo_add "$3" "${4:-}"
          ;;
        list) [[ $# -eq 2 ]] || { usage; exit 2; }; cmd_repo_list ;;
        status) [[ $# -eq 3 ]] || { usage; exit 2; }; cmd_repo_status "$3" ;;
        refresh) [[ $# -eq 3 ]] || { usage; exit 2; }; acquire_global_lock; cmd_repo_refresh "$3" ;;
        audit)
          [[ $# -ge 2 && $# -le 3 ]] || { usage; exit 2; }
          acquire_global_lock
          cmd_repo_audit "${3:---all}"
          ;;
        remove)
          [[ $# -ge 3 && $# -le 4 ]] || { usage; exit 2; }
          [[ $# -eq 3 || "$4" == "--manual" ]] || { usage; exit 2; }
          acquire_global_lock
          cmd_repo_remove "$3" "${4:-}"
          ;;
        *) usage; exit 2 ;;
      esac
      ;;
    -h|--help|help|'') usage ;;
    *) usage; exit 2 ;;
  esac
}
