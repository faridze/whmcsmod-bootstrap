#!/usr/bin/env bash
set -euo pipefail

PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PATH
umask 077

(( EUID == 0 )) || { echo "Run as root (sudo)." >&2; exit 2; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
DETECT_LIB="$SCRIPT_DIR/lib/install-detect.sh"
[[ -f "$DETECT_LIB" && ! -L "$DETECT_LIB" ]] || { echo "Installer detection library missing: $DETECT_LIB" >&2; exit 2; }
# shellcheck disable=SC1090
source "$DETECT_LIB"

TARGET_NAME="whmcs1"
WHMCS_ROOT=""
WHMCS_RUN_USER=""
PHP_BIN=""
COMPOSER_BIN=""
REPOS_ROOT="/opt/whmcs-modules"
STATE_ROOT="/var/lib/whmcsmod"
BACKUP_ROOT="/var/backups/whmcsmod"
TRUSTED_TAG_SIGNING_FINGERPRINT=""
TRUSTED_TAG_SIGNING_PUBLIC_KEY=""
PREFIX="/usr/local"
CONFIG_FILE="/etc/whmcsmod/config.conf"
TARGETS_DIR=""

while (($#)); do
  case "$1" in
    --target) TARGET_NAME="${2:-}"; shift 2 ;;
    --whmcs-root) WHMCS_ROOT="${2:-}"; shift 2 ;;
    --whmcs-run-user) WHMCS_RUN_USER="${2:-}"; shift 2 ;;
    --php-bin) PHP_BIN="${2:-}"; shift 2 ;;
    --composer-bin) COMPOSER_BIN="${2:-}"; shift 2 ;;
    --repos-root) REPOS_ROOT="${2:-}"; shift 2 ;;
    --state-root) STATE_ROOT="${2:-}"; shift 2 ;;
    --backup-root) BACKUP_ROOT="${2:-}"; shift 2 ;;
    --trusted-signing-fingerprint) TRUSTED_TAG_SIGNING_FINGERPRINT="${2:-}"; shift 2 ;;
    --trusted-signing-public-key) TRUSTED_TAG_SIGNING_PUBLIC_KEY="${2:-}"; shift 2 ;;
    --prefix) PREFIX="${2:-}"; shift 2 ;;
    --config) CONFIG_FILE="${2:-}"; shift 2 ;;
    --targets-dir) TARGETS_DIR="${2:-}"; shift 2 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done

[[ "$TARGET_NAME" =~ ^[a-z0-9][a-z0-9._-]{0,63}$ ]] || { echo "Invalid --target: $TARGET_NAME" >&2; exit 2; }
[[ -n "$WHMCS_ROOT" ]] || { echo "--whmcs-root is required" >&2; exit 2; }
[[ "$WHMCS_ROOT" == /* ]] || { echo "--whmcs-root must be absolute" >&2; exit 2; }
[[ -d "$WHMCS_ROOT" && ! -L "$WHMCS_ROOT" && -f "$WHMCS_ROOT/init.php" && ! -L "$WHMCS_ROOT/init.php" ]] || {
  echo "Invalid WHMCS root: $WHMCS_ROOT" >&2
  exit 2
}
WHMCS_ROOT="$(cd "$WHMCS_ROOT" && pwd -P)"

if [[ -z "$WHMCS_RUN_USER" ]]; then
  WHMCS_RUN_USER="$(whmcsmod_detect_runtime_user "$WHMCS_ROOT")" || exit 2
fi
[[ -n "$WHMCS_RUN_USER" && "$WHMCS_RUN_USER" != root ]] || { echo "Unable to determine non-root WHMCS runtime user; pass --whmcs-run-user USER" >&2; exit 2; }
id -u "$WHMCS_RUN_USER" >/dev/null 2>&1 || { echo "Unknown WHMCS runtime user: $WHMCS_RUN_USER" >&2; exit 2; }

if [[ -z "$PHP_BIN" ]]; then
  PHP_BIN="$(whmcsmod_detect_php "$WHMCS_ROOT")" || exit 2
else
  [[ "$PHP_BIN" == /* ]] || { echo "--php-bin must be an absolute path" >&2; exit 2; }
fi
[[ -n "$PHP_BIN" && -x "$PHP_BIN" && ! -d "$PHP_BIN" ]] || { echo "PHP CLI not found or not executable; pass --php-bin /absolute/path/to/php" >&2; exit 2; }
PHP_BIN="$(readlink -f "$PHP_BIN")"

if [[ -z "$COMPOSER_BIN" ]]; then
  COMPOSER_BIN="$(whmcsmod_detect_composer || true)"
else
  [[ "$COMPOSER_BIN" == /* ]] || { echo "--composer-bin must be an absolute path" >&2; exit 2; }
fi
if [[ -n "$COMPOSER_BIN" ]]; then
  [[ -x "$COMPOSER_BIN" && ! -d "$COMPOSER_BIN" ]] || { echo "Composer is not executable: $COMPOSER_BIN" >&2; exit 2; }
  COMPOSER_BIN="$(readlink -f "$COMPOSER_BIN")"
fi

TRUSTED_TAG_SIGNING_FINGERPRINT="${TRUSTED_TAG_SIGNING_FINGERPRINT//[[:space:]]/}"
TRUSTED_TAG_SIGNING_FINGERPRINT="${TRUSTED_TAG_SIGNING_FINGERPRINT^^}"

if [[ -n "$TRUSTED_TAG_SIGNING_PUBLIC_KEY" ]]; then
  command -v gpg >/dev/null 2>&1 || { echo "gpg is required for --trusted-signing-public-key" >&2; exit 2; }
  [[ "$TRUSTED_TAG_SIGNING_PUBLIC_KEY" == /* ]] || { echo "--trusted-signing-public-key must be an absolute path" >&2; exit 2; }
  [[ -f "$TRUSTED_TAG_SIGNING_PUBLIC_KEY" && ! -L "$TRUSTED_TAG_SIGNING_PUBLIC_KEY" ]] || {
    echo "Trusted signing public key is not a regular file: $TRUSTED_TAG_SIGNING_PUBLIC_KEY" >&2
    exit 2
  }
  TRUSTED_TAG_SIGNING_PUBLIC_KEY="$(readlink -f "$TRUSTED_TAG_SIGNING_PUBLIC_KEY")"

  inspect_home="$(mktemp -d /tmp/whmcsmod-key-inspect.XXXXXX)"
  chmod 700 "$inspect_home"
  cleanup_inspect() { rm -rf -- "$inspect_home"; }
  trap cleanup_inspect EXIT
  GNUPGHOME="$inspect_home" gpg --batch --import "$TRUSTED_TAG_SIGNING_PUBLIC_KEY" >/dev/null 2>&1 || {
    echo "Unable to import trusted signing public key" >&2
    exit 2
  }
  mapfile -t imported_fingerprints < <(
    GNUPGHOME="$inspect_home" gpg --batch --with-colons --list-keys 2>/dev/null \
      | awk -F: '$1=="pub"{want=1; next} want && $1=="fpr"{print toupper($10); want=0}'
  )
  [[ ${#imported_fingerprints[@]} -eq 1 ]] || {
    echo "Trusted public key file must contain exactly one primary key" >&2
    exit 2
  }
  derived_fingerprint="${imported_fingerprints[0]}"
  [[ "$derived_fingerprint" =~ ^[A-F0-9]{40,64}$ ]] || {
    echo "Unable to determine trusted signing fingerprint" >&2
    exit 2
  }
  if [[ -n "$TRUSTED_TAG_SIGNING_FINGERPRINT" && "$TRUSTED_TAG_SIGNING_FINGERPRINT" != "$derived_fingerprint" ]]; then
    echo "Trusted signing fingerprint does not match supplied public key" >&2
    exit 2
  fi
  TRUSTED_TAG_SIGNING_FINGERPRINT="$derived_fingerprint"
  cleanup_inspect
  trap - EXIT
fi

[[ "$TRUSTED_TAG_SIGNING_FINGERPRINT" =~ ^[A-F0-9]{40,64}$ ]] || {
  echo "Provide either --trusted-signing-public-key FILE or --trusted-signing-fingerprint FINGERPRINT" >&2
  exit 2
}

config_parent="$(dirname "$CONFIG_FILE")"
[[ -n "$TARGETS_DIR" ]] || TARGETS_DIR="$config_parent/targets"
KEYS_DIR="$config_parent/keys"
for path in "$PREFIX" "$CONFIG_FILE" "$TARGETS_DIR" "$KEYS_DIR" "$REPOS_ROOT" "$STATE_ROOT" "$BACKUP_ROOT"; do
  [[ "$path" == /* ]] || { echo "All installation paths must be absolute: $path" >&2; exit 2; }
done

[[ -f "$SCRIPT_DIR/whmcsmod" && -f "$SCRIPT_DIR/lib/manifest.php" && -f "$SCRIPT_DIR/lib/common.sh" && -f "$SCRIPT_DIR/lib/deploy.sh" && -f "$SCRIPT_DIR/lib/release.sh" && -f "$SCRIPT_DIR/lib/commands.sh" && -f "$SCRIPT_DIR/lib/repo.sh" && -f "$SCRIPT_DIR/lib/self-update.sh" && -f "$SCRIPT_DIR/lib/ops.sh" && -f "$SCRIPT_DIR/lib/install-detect.sh" ]] || {
  echo "Run install.sh from a complete verified manager release bundle or repository checkout." >&2
  exit 2
}

if [[ -e "$CONFIG_FILE" ]]; then
  [[ -f "$CONFIG_FILE" && ! -L "$CONFIG_FILE" ]] || { echo "Refusing non-regular config: $CONFIG_FILE" >&2; exit 2; }
  config_uid="$(stat -c '%u' "$CONFIG_FILE")"
  config_mode="$(stat -c '%a' "$CONFIG_FILE")"
  [[ "$config_uid" == 0 ]] || { echo "Existing config must be root-owned: $CONFIG_FILE" >&2; exit 2; }
  (( (8#$config_mode & 8#022) == 0 )) || { echo "Existing config must not be group/world writable: $CONFIG_FILE" >&2; exit 2; }
  existing_fingerprint="$(grep -E '^TRUSTED_TAG_SIGNING_FINGERPRINT=' "$CONFIG_FILE" | tail -n1 | cut -d= -f2- || true)"
  existing_fingerprint="${existing_fingerprint//[\"\']/}"
  existing_fingerprint="${existing_fingerprint//[[:space:]]/}"
  existing_fingerprint="${existing_fingerprint^^}"
  [[ "$existing_fingerprint" =~ ^[A-F0-9]{40,64}$ ]] || {
    echo "Existing config does not contain a valid trusted signing fingerprint: $CONFIG_FILE" >&2
    exit 2
  }
  [[ "$existing_fingerprint" == "$TRUSTED_TAG_SIGNING_FINGERPRINT" ]] || {
    echo "Existing config trusts a different signing fingerprint; refusing automatic trust change" >&2
    exit 2
  }
fi

install -d -m 0755 "$config_parent" "$TARGETS_DIR" "$KEYS_DIR"
if [[ -n "$TRUSTED_TAG_SIGNING_PUBLIC_KEY" ]]; then
  key_target="$KEYS_DIR/release-signing-public.asc"
  [[ ! -e "$key_target" || ( -f "$key_target" && ! -L "$key_target" ) ]] || {
    echo "Refusing non-regular trusted public key destination: $key_target" >&2
    exit 2
  }
  key_tmp="$(mktemp "$KEYS_DIR/.release-signing-public.XXXXXX")"
  install -m 0644 "$TRUSTED_TAG_SIGNING_PUBLIC_KEY" "$key_tmp"
  mv -f -- "$key_tmp" "$key_target"
  chown root:root "$key_target"
  chmod 0644 "$key_target"
  gpg --batch --import "$key_target" >/dev/null 2>&1 || {
    echo "Unable to import trusted signing public key into root GPG keyring" >&2
    exit 2
  }
fi

install -d -m 0755 "$PREFIX/sbin" "$PREFIX/lib/whmcsmod"
install -m 0755 "$SCRIPT_DIR/whmcsmod" "$PREFIX/sbin/whmcsmod"
install -m 0755 "$SCRIPT_DIR/lib/manifest.php" "$PREFIX/lib/whmcsmod/manifest.php"
install -m 0644 "$SCRIPT_DIR/VERSION" "$PREFIX/lib/whmcsmod/VERSION"
for lib in common.sh deploy.sh release.sh commands.sh repo.sh self-update.sh ops.sh; do
  install -m 0644 "$SCRIPT_DIR/lib/$lib" "$PREFIX/lib/whmcsmod/$lib"
done
install -d -m 0700 "$REPOS_ROOT" "$STATE_ROOT" "$STATE_ROOT/targets" "$STATE_ROOT/targets/$TARGET_NAME" "$STATE_ROOT/targets/$TARGET_NAME/modules" "$BACKUP_ROOT" "$BACKUP_ROOT/$TARGET_NAME"

if [[ -e "$CONFIG_FILE" ]]; then
  echo "Config already exists; leaving it unchanged: $CONFIG_FILE"
else
  tmp="$(mktemp "$config_parent/.whmcsmod-config.XXXXXX")"
  chmod 0600 "$tmp"
  {
    printf '# WHMCS Module Manager global configuration\n'
    printf 'DEFAULT_TARGET=%q\n' "$TARGET_NAME"
    printf 'TARGETS_DIR=%q\n' "$TARGETS_DIR"
    printf 'REPOS_ROOT=%q\n' "$REPOS_ROOT"
    printf 'STATE_ROOT=%q\n' "$STATE_ROOT"
    printf 'BACKUP_ROOT=%q\n' "$BACKUP_ROOT"
    printf 'BACKUP_KEEP=%q\n' 10
    printf 'BACKUP_AUTO_PRUNE=%q\n' 0
    printf 'GIT_REMOTE=%q\n' origin
    printf 'TRUSTED_TAG_SIGNING_FINGERPRINT=%q\n' "$TRUSTED_TAG_SIGNING_FINGERPRINT"
  } > "$tmp"
  mv -f -- "$tmp" "$CONFIG_FILE"
  chmod 0600 "$CONFIG_FILE"
fi

target_file="$TARGETS_DIR/$TARGET_NAME.conf"
if [[ -e "$target_file" ]]; then
  [[ -f "$target_file" && ! -L "$target_file" ]] || { echo "Refusing non-regular target profile: $target_file" >&2; exit 2; }
  echo "Target profile already exists; leaving it unchanged: $target_file"
else
  tmp="$(mktemp "$TARGETS_DIR/.${TARGET_NAME}.XXXXXX")"
  chmod 0600 "$tmp"
  {
    printf '# WHMCS target: %s\n' "$TARGET_NAME"
    printf 'WHMCS_ROOT=%q\n' "$WHMCS_ROOT"
    printf 'WHMCS_RUN_USER=%q\n' "$WHMCS_RUN_USER"
    printf 'PHP_BIN=%q\n' "$PHP_BIN"
    printf 'COMPOSER_BIN=%q\n' "$COMPOSER_BIN"
  } > "$tmp"
  mv -f -- "$tmp" "$target_file"
  chmod 0600 "$target_file"
fi

echo "Installed: $PREFIX/sbin/whmcsmod"
echo "Config:    $CONFIG_FILE"
echo "Target:    $TARGET_NAME ($target_file)"
echo "WHMCS:     $WHMCS_ROOT"
echo "PHP:       $PHP_BIN"
echo "User:      $WHMCS_RUN_USER"
echo "Composer:  ${COMPOSER_BIN:-not configured}"
echo "Repos:     $REPOS_ROOT"
echo "Signing:   $TRUSTED_TAG_SIGNING_FINGERPRINT"
echo
echo "Next:"
echo "  clone module repositories under $REPOS_ROOT/<module-id>"
echo "  sudo $PREFIX/sbin/whmcsmod doctor"
echo "  sudo $PREFIX/sbin/whmcsmod target list"
echo "  sudo $PREFIX/sbin/whmcsmod list"
