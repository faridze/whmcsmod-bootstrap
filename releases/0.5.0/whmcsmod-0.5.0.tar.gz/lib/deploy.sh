# WHMCS filesystem, inventory, backup and execution helpers.
safe_relative() {
  local p="$1"
  [[ -n "$p" && "$p" != /* && "$p" =~ ^[A-Za-z0-9._/@-]+$ && ! "$p" =~ (^|/)\.\.(/|$) ]] \
    || fail "unsafe relative path: $p"
}

validate_target_path() {
  local relative="$1"
  safe_relative "$relative"
  local current="$WHMCS_ROOT" part parent target
  parent="$(dirname "$relative")"
  IFS='/' read -r -a parts <<< "$parent"
  for part in "${parts[@]}"; do
    [[ -n "$part" && "$part" != "." ]] || continue
    current="$current/$part"
    [[ ! -L "$current" ]] || fail "symlink path component refused: $current"
    if [[ -e "$current" ]]; then
      [[ -d "$current" ]] || fail "deployment path component is not a directory: $current"
    fi
  done
  target="$WHMCS_ROOT/$relative"
  [[ ! -L "$target" ]] || fail "symlink destination refused: $relative"
  [[ ! -e "$target" || -f "$target" ]] || fail "non-regular destination refused: $relative"
}

ensure_target_path() {
  local relative="$1"
  validate_target_path "$relative"
  local current="$WHMCS_ROOT" part parent
  parent="$(dirname "$relative")"
  IFS='/' read -r -a parts <<< "$parent"
  for part in "${parts[@]}"; do
    [[ -n "$part" && "$part" != "." ]] || continue
    current="$current/$part"
    if [[ ! -e "$current" ]]; then
      mkdir -m 0755 "$current"
    fi
    [[ ! -L "$current" ]] || fail "symlink path component refused: $current"
    [[ -d "$current" ]] || fail "deployment path component is not a directory: $current"
  done
  local target="$WHMCS_ROOT/$relative" parent_real
  parent_real="$(cd "$(dirname "$target")" && pwd -P)"
  [[ "$parent_real" == "$WHMCS_ROOT" || "$parent_real" == "$WHMCS_ROOT/"* ]] \
    || fail "destination escapes WHMCS_ROOT: $relative"
  [[ ! -L "$target" ]] || fail "symlink destination refused: $relative"
  [[ ! -e "$target" || -f "$target" ]] || fail "non-regular destination refused: $relative"
}

load_deploy_files() {
  local source="$1" manifest="$2" list_file relative existing
  list_file="$(manifest_get "$manifest" deploy.files)"
  safe_relative "$list_file"
  [[ -f "$source/$list_file" && ! -L "$source/$list_file" ]] || fail "deploy file list missing: $list_file"
  DEPLOY_FILES=()
  while IFS= read -r relative || [[ -n "$relative" ]]; do
    relative="${relative%$'\r'}"
    [[ -n "$relative" ]] || continue
    [[ "$relative" != \#* ]] || continue
    safe_relative "$relative"
    [[ -f "$source/$relative" && ! -L "$source/$relative" ]] || fail "deploy source missing or symlinked: $relative"
    for existing in "${DEPLOY_FILES[@]:-}"; do
      [[ "$existing" != "$relative" ]] || fail "duplicate deploy path: $relative"
    done
    validate_target_path "$relative"
    DEPLOY_FILES+=("$relative")
  done < "$source/$list_file"
  ((${#DEPLOY_FILES[@]} > 0)) || fail "deploy file list is empty"
}

check_file_collisions() {
  local module="$1" relative other_state other_module
  shopt -s nullglob
  for other_state in "$STATE_ROOT"/modules/*/current-files.txt; do
    other_module="$(basename "$(dirname "$other_state")")"
    [[ "$other_module" != "$module" ]] || continue
    for relative in "${DEPLOY_FILES[@]}"; do
      if grep -Fxq "$relative" "$other_state"; then
        fail "file collision: $relative is already managed by module $other_module"
      fi
    done
  done
  shopt -u nullglob
}

assert_install_targets_free() {
  local relative
  for relative in "${DEPLOY_FILES[@]}"; do
    if [[ -e "$WHMCS_ROOT/$relative" || -L "$WHMCS_ROOT/$relative" ]]; then
      fail "install would overwrite an existing unmanaged path: $relative (use adopt if production already matches a signed release)"
    fi
  done
}

classify_takeover_files() {
  local source="$1" relative source_hash target_hash target
  TAKEOVER_IDENTICAL=0
  TAKEOVER_CHANGED=0
  TAKEOVER_MISSING=0
  for relative in "${DEPLOY_FILES[@]}"; do
    validate_target_path "$relative"
    target="$WHMCS_ROOT/$relative"
    if [[ ! -e "$target" ]]; then
      TAKEOVER_MISSING=$((TAKEOVER_MISSING + 1))
      continue
    fi
    source_hash="$(sha256sum "$source/$relative" | awk '{print $1}')"
    target_hash="$(sha256sum "$target" | awk '{print $1}')"
    if [[ "$source_hash" == "$target_hash" ]]; then
      TAKEOVER_IDENTICAL=$((TAKEOVER_IDENTICAL + 1))
    else
      TAKEOVER_CHANGED=$((TAKEOVER_CHANGED + 1))
    fi
  done
  printf 'IDENTICAL: %d\n' "$TAKEOVER_IDENTICAL"
  printf 'CHANGED:   %d\n' "$TAKEOVER_CHANGED"
  printf 'MISSING:   %d\n' "$TAKEOVER_MISSING"
}

record_missing_parent_dirs() {
  local output="$1" relative parent current part parent_relative
  : > "$output"
  for relative in "${DEPLOY_FILES[@]}"; do
    validate_target_path "$relative"
    parent="$(dirname "$relative")"
    [[ "$parent" != "." ]] || continue
    current="$WHMCS_ROOT"
    parent_relative=""
    IFS='/' read -r -a parts <<< "$parent"
    for part in "${parts[@]}"; do
      [[ -n "$part" && "$part" != "." ]] || continue
      current="$current/$part"
      parent_relative="${parent_relative:+$parent_relative/}$part"
      [[ ! -L "$current" ]] || fail "symlink path component refused: $current"
      if [[ -e "$current" ]]; then
        [[ -d "$current" ]] || fail "deployment path component is not a directory: $current"
      else
        safe_relative "$parent_relative"
        printf '%s\n' "$parent_relative" >> "$output"
      fi
    done
  done
  sort -u -o "$output" "$output"
}

cleanup_missing_parent_dirs() {
  local list_file="$1" depth relative current part unsafe
  [[ -f "$list_file" && ! -L "$list_file" ]] || return 0
  while read -r depth relative; do
    [[ -n "${relative:-}" ]] || continue
    safe_relative "$relative"
    current="$WHMCS_ROOT"
    unsafe=0
    IFS='/' read -r -a parts <<< "$relative"
    for part in "${parts[@]}"; do
      [[ -n "$part" && "$part" != "." ]] || continue
      current="$current/$part"
      if [[ -L "$current" ]]; then
        warn "rollback directory cleanup skipped symlink path: $relative"
        unsafe=1
        break
      fi
      if [[ -e "$current" && ! -d "$current" ]]; then
        unsafe=1
        break
      fi
    done
    (( unsafe == 0 )) || continue
    [[ -d "$WHMCS_ROOT/$relative" ]] || continue
    rmdir -- "$WHMCS_ROOT/$relative" 2>/dev/null || true
  done < <(awk -F/ 'NF {print NF, $0}' "$list_file" | sort -k1,1nr -k2,2r)
}

union_inventory() {
  local state_dir="$1"
  local tmp="$2"
  : > "$tmp"
  if [[ -f "$state_dir/current-files.txt" ]]; then
    cat "$state_dir/current-files.txt" >> "$tmp"
  fi
  printf '%s\n' "${DEPLOY_FILES[@]}" >> "$tmp"
  sort -u -o "$tmp" "$tmp"
}

backup_current_state() {
  local module="$1" target_ref="$2" union_file="$3"
  local root state_dir stamp backup relative
  root="$(backup_dir_for "$module")"
  state_dir="$(state_dir_for "$module")"
  install -d -m 0700 "$root"
  stamp="$(date +%Y%m%d-%H%M%S)-${target_ref//\//_}"
  backup="$root/$stamp"
  install -d -m 0700 "$backup"
  cp "$union_file" "$backup/files.txt"
  record_missing_parent_dirs "$backup/missing-dirs.txt"
  : > "$backup/present.txt"
  while IFS= read -r relative || [[ -n "$relative" ]]; do
    [[ -n "$relative" ]] || continue
    validate_target_path "$relative"
    if [[ -f "$WHMCS_ROOT/$relative" ]]; then
      echo "$relative" >> "$backup/present.txt"
    fi
  done < "$union_file"
  if [[ -s "$backup/present.txt" ]]; then
    tar -C "$WHMCS_ROOT" -czf "$backup/files.tgz" -T "$backup/present.txt"
  else
    tar -czf "$backup/files.tgz" --files-from /dev/null
  fi
  if [[ -d "$state_dir" ]]; then
    tar -C "$STATE_ROOT/modules" -czf "$backup/state.tgz" "$module"
  else
    tar -czf "$backup/state.tgz" --files-from /dev/null
  fi
  {
    echo "module=$module"
    echo "created=$(date -Is)"
    echo "target_ref=$target_ref"
    echo "previous_version=$(cat "$state_dir/current-version" 2>/dev/null || echo none)"
    echo "previous_ref=$(cat "$state_dir/current-ref" 2>/dev/null || echo none)"
  } > "$backup/meta"
  echo "$backup"
}

backup_composer_vendors() {
  local backup="$1" manifest="$2" path index=0 vendor
  while IFS= read -r path || [[ -n "$path" ]]; do
    [[ -n "$path" ]] || continue
    safe_relative "$path"
    vendor="$WHMCS_ROOT/$path/vendor"
    echo "$path" > "$backup/composer-vendor-$index.path"
    if [[ -d "$vendor" && ! -L "$vendor" ]]; then
      tar -C "$WHMCS_ROOT/$path" -czf "$backup/composer-vendor-$index.tgz" vendor
    elif [[ -e "$vendor" ]]; then
      fail "composer vendor path is not a regular directory: $vendor"
    fi
    index=$((index + 1))
  done < <("$PHP_BIN" "$MANIFEST_TOOL" composer-paths "$manifest")
}

restore_backup() {
  local module="$1" backup="$2" relative pathfile vendor_path archive state_dir
  [[ -d "$backup" && ! -L "$backup" ]] || fail "backup not found: $backup"
  for required in files.txt present.txt files.tgz state.tgz; do
    [[ -f "$backup/$required" ]] || fail "incomplete backup: $backup/$required"
  done
  while IFS= read -r relative || [[ -n "$relative" ]]; do
    [[ -n "$relative" ]] || continue
    validate_target_path "$relative"
    if ! grep -Fxq "$relative" "$backup/present.txt"; then
      rm -f -- "$WHMCS_ROOT/$relative"
    fi
  done < "$backup/files.txt"
  tar -C "$WHMCS_ROOT" -xzf "$backup/files.tgz"

  shopt -s nullglob
  for pathfile in "$backup"/composer-vendor-*.path; do
    vendor_path="$(cat "$pathfile")"
    safe_relative "$vendor_path"
    archive="${pathfile%.path}.tgz"
    rm -rf -- "$WHMCS_ROOT/$vendor_path/vendor"
    [[ -f "$archive" ]] && tar -C "$WHMCS_ROOT/$vendor_path" -xzf "$archive"
  done
  shopt -u nullglob

  state_dir="$(state_dir_for "$module")"
  rm -rf -- "$state_dir"
  if [[ -s "$backup/state.tgz" ]]; then
    install -d -m 0700 "$STATE_ROOT/modules"
    tar -C "$STATE_ROOT/modules" -xzf "$backup/state.tgz"
  fi

  if [[ -e "$backup/missing-dirs.txt" ]]; then
    [[ -f "$backup/missing-dirs.txt" && ! -L "$backup/missing-dirs.txt" ]] \
      || fail "invalid missing directory inventory: $backup/missing-dirs.txt"
    cleanup_missing_parent_dirs "$backup/missing-dirs.txt"
  fi
}

copy_deploy_files() {
  local source="$1" relative target temp
  DEPLOY_TEMPS=()
  for relative in "${DEPLOY_FILES[@]}"; do
    ensure_target_path "$relative"
    target="$WHMCS_ROOT/$relative"
    temp="${target}.whmcsmod-new.$$"
    DEPLOY_TEMPS+=("$temp")
    cp -- "$source/$relative" "$temp"
    if [[ -f "$target" ]]; then
      chmod --reference="$target" "$temp"
      chown --reference="$target" "$temp" 2>/dev/null || true
    else
      chmod 0644 "$temp"
    fi
    mv -f -- "$temp" "$target"
  done
}

remove_stale_files() {
  local state_dir="$1" manifest="$2" relative
  local remove_stale=1
  remove_stale="$(manifest_bool "$manifest" deploy.remove_stale 2>/dev/null || echo 1)"
  [[ "$remove_stale" == "1" ]] || return 0
  [[ -f "$state_dir/current-files.txt" ]] || return 0
  local keep candidate
  while IFS= read -r relative || [[ -n "$relative" ]]; do
    [[ -n "$relative" ]] || continue
    keep=0
    for candidate in "${DEPLOY_FILES[@]}"; do
      if [[ "$candidate" == "$relative" ]]; then
        keep=1
        break
      fi
    done
    if (( keep == 0 )); then
      validate_target_path "$relative"
      rm -f -- "$WHMCS_ROOT/$relative"
    fi
  done < "$state_dir/current-files.txt"
}

run_validate_hook() {
  local source="$1" manifest="$2" path type
  path="$(manifest_get "$manifest" hooks.validate.path 2>/dev/null || true)"
  [[ -n "$path" ]] || return 0
  type="$(manifest_get "$manifest" hooks.validate.type)"
  case "$type" in
    php) "$PHP_BIN" "$source/$path" ;;
    shell) PHP_BIN="$PHP_BIN" COMPOSER_BIN="$COMPOSER_BIN" /bin/bash "$source/$path" ;;
    *) fail "unsupported validate hook type: $type" ;;
  esac
}

run_healthcheck() {
  local source="$1" manifest="$2" mode="$3" path type temp arg
  path="$(manifest_get "$manifest" hooks.healthcheck.path 2>/dev/null || true)"
  [[ -n "$path" ]] || return 0
  type="$(manifest_get "$manifest" hooks.healthcheck.type)"
  temp="$(mktemp /tmp/whmcsmod-healthcheck.XXXXXX)"
  cp -- "$source/$path" "$temp"
  chmod 0644 "$temp"
  HEALTHCHECK_TEMP="$temp"
  local args=("--whmcs-root" "$WHMCS_ROOT")
  local field="hooks.healthcheck.check_args"
  [[ "$mode" == "migrate" ]] && field="hooks.healthcheck.migrate_args"
  while IFS= read -r arg || [[ -n "$arg" ]]; do
    [[ -n "$arg" ]] && args+=("$arg")
  done < <(manifest_list "$manifest" "$field" 2>/dev/null || true)
  case "$type" in
    php) runuser -u "$WHMCS_RUN_USER" -- "$PHP_BIN" "$temp" "${args[@]}" ;;
    shell) runuser -u "$WHMCS_RUN_USER" -- /bin/bash "$temp" "${args[@]}" ;;
    *) fail "unsupported healthcheck hook type: $type" ;;
  esac
  rm -f -- "$temp"
  HEALTHCHECK_TEMP=""
}

run_composer() {
  local manifest="$1" path
  while IFS= read -r path || [[ -n "$path" ]]; do
    [[ -n "$path" ]] || continue
    [[ -n "$COMPOSER_BIN" ]] || fail "module requires Composer but COMPOSER_BIN is empty"
    safe_relative "$path"
    [[ -f "$WHMCS_ROOT/$path/composer.json" ]] || fail "composer.json missing at $path"
    COMPOSER_ALLOW_SUPERUSER=1 "$COMPOSER_BIN" install \
      --working-dir="$WHMCS_ROOT/$path" --no-dev --prefer-dist \
      --optimize-autoloader --no-interaction
  done < <("$PHP_BIN" "$MANIFEST_TOOL" composer-paths "$manifest")
}

write_state() {
  local module="$1" ref="$2" version="$3" commit="$4" state_dir hashfile relative
  state_dir="$(state_dir_for "$module")"
  install -d -m 0700 "$state_dir"
  printf '%s\n' "${DEPLOY_FILES[@]}" | sort -u > "$state_dir/current-files.txt"
  hashfile="$state_dir/current-files.sha256"
  : > "$hashfile"
  while IFS= read -r relative || [[ -n "$relative" ]]; do
    [[ -n "$relative" ]] || continue
    [[ -f "$WHMCS_ROOT/$relative" ]] || fail "deployed file vanished before state write: $relative"
    printf '%s  %s\n' "$(sha256sum "$WHMCS_ROOT/$relative" | awk '{print $1}')" "$relative" >> "$hashfile"
  done < "$state_dir/current-files.txt"
  echo "$version" > "$state_dir/current-version"
  echo "$ref" > "$state_dir/current-ref"
  echo "$commit" > "$state_dir/current-commit"
  date -Is > "$state_dir/last-successful-deploy"
}

check_release_consistency() {
  local source="$1" manifest="$2" ref="$3" version_file tag_prefix version ref_version metadata
  version_file="$(manifest_get "$manifest" release.version_file)"
  tag_prefix="$(manifest_get "$manifest" release.tag_prefix 2>/dev/null || echo v)"
  version="$(tr -d '[:space:]' < "$source/$version_file")"
  [[ -n "$version" ]] || fail "empty version file: $version_file"
  semver_is_valid "$version" || fail "invalid semantic version in $version_file: $version"
  ref_version="$(release_ref_version "$ref" "$tag_prefix")" || fail "release ref is not a valid semantic tag: $ref"
  [[ "$ref_version" == "$version" ]] || fail "tag $ref does not match version $version"
  metadata="$(manifest_get "$manifest" release.metadata 2>/dev/null || true)"
  if [[ -n "$metadata" ]]; then
    "$PHP_BIN" -r '
      $j=json_decode(file_get_contents($argv[1]), true);
      if (!is_array($j) || !isset($j["version"]) || (string)$j["version"] !== $argv[2]) {
        fwrite(STDERR, "release metadata version mismatch\n"); exit(1);
      }
    ' "$source/$metadata" "$version" || fail "release metadata does not match version"
  fi
  echo "$version"
}
