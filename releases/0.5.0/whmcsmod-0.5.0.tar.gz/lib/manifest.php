#!/usr/bin/env php
<?php
declare(strict_types=1);

function fail(string $message, int $code = 2): never {
    fwrite(STDERR, "manifest: {$message}\n");
    exit($code);
}

function loadManifest(string $path): array {
    if (!is_file($path) || is_link($path)) {
        fail("manifest is not a regular file: {$path}");
    }
    $raw = file_get_contents($path);
    if ($raw === false) {
        fail("unable to read: {$path}");
    }
    try {
        $data = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
    } catch (Throwable $e) {
        fail("invalid JSON: " . $e->getMessage());
    }
    if (!is_array($data)) {
        fail("top-level JSON value must be an object");
    }
    return $data;
}

function safeRel(string $value, string $label): string {
    if ($value === '' || str_starts_with($value, '/') || str_contains($value, "\0")) {
        fail("{$label} must be a non-empty relative path");
    }
    foreach (explode('/', $value) as $part) {
        if ($part === '..') {
            fail("{$label} must not contain '..'");
        }
    }
    if (!preg_match('#^[A-Za-z0-9._/-]+$#', $value)) {
        fail("{$label} contains unsafe characters");
    }
    return $value;
}

function optionalPath(array $data, array $keys): ?string {
    $value = $data;
    foreach ($keys as $key) {
        if (!is_array($value) || !array_key_exists($key, $value)) {
            return null;
        }
        $value = $value[$key];
    }
    if ($value === null || $value === '') {
        return null;
    }
    if (!is_string($value)) {
        fail(implode('.', $keys) . ' must be a string');
    }
    return safeRel($value, implode('.', $keys));
}

function validate(array $m, ?string $repoRoot = null): void {
    if (($m['schema'] ?? null) !== 1) {
        fail('schema must be integer 1');
    }
    $id = $m['id'] ?? null;
    if (!is_string($id) || !preg_match('/^[a-z0-9][a-z0-9._-]{1,63}$/', $id)) {
        fail('id must match ^[a-z0-9][a-z0-9._-]{1,63}$');
    }
    $name = $m['name'] ?? null;
    if (!is_string($name) || trim($name) === '' || strlen($name) > 120) {
        fail('name must be a non-empty string up to 120 bytes');
    }
    if (!isset($m['release']) || !is_array($m['release'])) {
        fail('release object is required');
    }
    $versionFile = $m['release']['version_file'] ?? null;
    if (!is_string($versionFile)) {
        fail('release.version_file is required');
    }
    safeRel($versionFile, 'release.version_file');
    $prefix = $m['release']['tag_prefix'] ?? 'v';
    if (!is_string($prefix) || !preg_match('/^[A-Za-z0-9_-]{0,8}$/', $prefix)) {
        fail('release.tag_prefix contains unsafe characters');
    }
    if (isset($m['release']['metadata'])) {
        if (!is_string($m['release']['metadata'])) {
            fail('release.metadata must be a string');
        }
        safeRel($m['release']['metadata'], 'release.metadata');
    }

    if (!isset($m['deploy']) || !is_array($m['deploy'])) {
        fail('deploy object is required');
    }
    $deployFiles = $m['deploy']['files'] ?? null;
    if (!is_string($deployFiles)) {
        fail('deploy.files is required');
    }
    safeRel($deployFiles, 'deploy.files');
    if (isset($m['deploy']['remove_stale']) && !is_bool($m['deploy']['remove_stale'])) {
        fail('deploy.remove_stale must be boolean');
    }

    if (isset($m['composer'])) {
        if (!is_array($m['composer']) || !array_is_list($m['composer'])) {
            fail('composer must be an array');
        }
        foreach ($m['composer'] as $i => $entry) {
            if (!is_array($entry)) {
                fail("composer[{$i}] must be an object");
            }
            $path = $entry['path'] ?? null;
            if (!is_string($path)) {
                fail("composer[{$i}].path is required");
            }
            safeRel($path, "composer[{$i}].path");
        }
    }

    if (isset($m['hooks'])) {
        if (!is_array($m['hooks'])) {
            fail('hooks must be an object');
        }
        foreach (['validate', 'healthcheck'] as $hookName) {
            if (!isset($m['hooks'][$hookName])) {
                continue;
            }
            $hook = $m['hooks'][$hookName];
            if (!is_array($hook)) {
                fail("hooks.{$hookName} must be an object");
            }
            $path = $hook['path'] ?? null;
            $type = $hook['type'] ?? null;
            if (!is_string($path) || !is_string($type)) {
                fail("hooks.{$hookName}.path and type are required");
            }
            safeRel($path, "hooks.{$hookName}.path");
            if (!in_array($type, ['php', 'shell'], true)) {
                fail("hooks.{$hookName}.type must be php or shell");
            }
            foreach (['check_args', 'migrate_args'] as $argsName) {
                if (!isset($hook[$argsName])) {
                    continue;
                }
                if (!is_array($hook[$argsName]) || !array_is_list($hook[$argsName])) {
                    fail("hooks.{$hookName}.{$argsName} must be an array");
                }
                foreach ($hook[$argsName] as $arg) {
                    if (!is_string($arg) || !preg_match('/^--[A-Za-z0-9][A-Za-z0-9._=-]*$/', $arg)) {
                        fail("unsafe hook argument in hooks.{$hookName}.{$argsName}");
                    }
                }
            }
        }
    }

    if ($repoRoot !== null) {
        $repoRoot = rtrim($repoRoot, '/');
        foreach ([$versionFile, $deployFiles] as $relative) {
            if (!is_file($repoRoot . '/' . $relative) || is_link($repoRoot . '/' . $relative)) {
                fail("required file missing or symlinked: {$relative}");
            }
        }
        foreach ([
            optionalPath($m, ['release', 'metadata']),
            optionalPath($m, ['hooks', 'validate', 'path']),
            optionalPath($m, ['hooks', 'healthcheck', 'path']),
        ] as $relative) {
            if ($relative !== null && (!is_file($repoRoot . '/' . $relative) || is_link($repoRoot . '/' . $relative))) {
                fail("referenced file missing or symlinked: {$relative}");
            }
        }
    }
}

function dotGet(array $data, string $path): mixed {
    $value = $data;
    foreach (explode('.', $path) as $key) {
        if (!is_array($value) || !array_key_exists($key, $value)) {
            return null;
        }
        $value = $value[$key];
    }
    return $value;
}

$cmd = $argv[1] ?? '';
$manifestPath = $argv[2] ?? '';
if ($cmd === '' || $manifestPath === '') {
    fail('usage: manifest.php validate|get|list|bool <manifest> [path] [repo-root]');
}
$m = loadManifest($manifestPath);

switch ($cmd) {
    case 'validate':
        validate($m, $argv[3] ?? null);
        echo "ok\n";
        break;
    case 'get':
        validate($m);
        $path = $argv[3] ?? '';
        if ($path === '') fail('get requires a dot path');
        $value = dotGet($m, $path);
        if ($value === null) exit(4);
        if (!is_scalar($value)) fail("{$path} is not scalar");
        if (is_bool($value)) echo $value ? "1\n" : "0\n";
        else echo (string)$value, "\n";
        break;
    case 'list':
        validate($m);
        $path = $argv[3] ?? '';
        if ($path === '') fail('list requires a dot path');
        $value = dotGet($m, $path);
        if ($value === null) exit(4);
        if (!is_array($value) || !array_is_list($value)) fail("{$path} is not a list");
        foreach ($value as $item) {
            if (!is_scalar($item)) fail("{$path} contains a non-scalar item");
            echo (string)$item, "\n";
        }
        break;
    case 'bool':
        validate($m);
        $path = $argv[3] ?? '';
        if ($path === '') fail('bool requires a dot path');
        $value = dotGet($m, $path);
        if ($value === null) exit(4);
        if (!is_bool($value)) fail("{$path} is not boolean");
        echo $value ? "1\n" : "0\n";
        break;
    case 'composer-paths':
        validate($m);
        foreach (($m['composer'] ?? []) as $entry) {
            echo $entry['path'], "\n";
        }
        break;
    default:
        fail("unknown command: {$cmd}");
}
