# Shared configuration, target, manifest and Git security helpers.
fail() { echo "$PROGRAM: ERROR: $*" >&2; exit 1; }
warn() { echo "$PROGRAM: WARNING: $*" >&2; }
need_cmd() { command -v "$1" >/dev/null 2>&1 || fail "required command not found: $1"; }
require_root() { (( EUID == 0 )) || fail "run this command as root (sudo)"; }

safe_abs_dir() {
  local path="$1" label="$2"
  [[ "$path" == /* ]] || fail "$label must be an absolute path: $path"
  [[ -d "$path" && ! -L "$path" ]] || fail "$label is not a regular directory: $path"
  (cd "$path" && pwd -P)
}

secure_root_owned_path() {
  local path="$1" label="$2"
  [[ ! -L "$path" ]] || fail "$label must not be a symlink: $path"
  local uid mode
  uid="$(stat -c '%u' "$path")"
  mode="$(stat -c '%a' "$path")"
  [[ "$uid" == "0" ]] || fail "$label must be root-owned: $path"
  (( (8#$mode & 8#022) == 0 )) || fail "$label must not be group/world writable: $path"
}

validate_target_id() {
  [[ "$1" =~ ^[a-z0-9][a-z0-9._-]{0,63}$ ]] || fail "invalid target id: $1"
}

target_profile_for() {
  local target="$1"
  validate_target_id "$target"
  echo "$TARGETS_DIR/$target.conf"
}

state_dir_for() { echo "$STATE_ROOT/modules/$1"; }
backup_dir_for() { echo "$BACKUP_ROOT/$1"; }

load_config() {
  [[ -f "$CONFIG_FILE" && ! -L "$CONFIG_FILE" ]] || fail "missing config: $CONFIG_FILE"
  secure_root_owned_path "$CONFIG_FILE" "config"

  unset WHMCS_ROOT WHMCS_RUN_USER PHP_BIN COMPOSER_BIN DEFAULT_TARGET TARGETS_DIR \
    REPOS_ROOT STATE_ROOT BACKUP_ROOT GIT_REMOTE TRUSTED_TAG_SIGNING_FINGERPRINT GITHUB_APP_CLIENT_ID
  # shellcheck disable=SC1090
  source "$CONFIG_FILE"

  : "${REPOS_ROOT:=/opt/whmcs-modules}"
  : "${STATE_ROOT:=/var/lib/whmcsmod}"
  : "${BACKUP_ROOT:=/var/backups/whmcsmod}"
  : "${GIT_REMOTE:=origin}"
  : "${TRUSTED_TAG_SIGNING_FINGERPRINT:=}"
  : "${GITHUB_APP_CLIENT_ID:=}"
  : "${TARGETS_DIR:=$(dirname "$CONFIG_FILE")/targets}"

  local global_repos_root="$REPOS_ROOT"
  local global_state_root="$STATE_ROOT"
  local global_backup_root="$BACKUP_ROOT"
  local global_git_remote="$GIT_REMOTE"
  local global_fingerprint="$TRUSTED_TAG_SIGNING_FINGERPRINT"
  local global_github_client_id="$GITHUB_APP_CLIENT_ID"
  local global_targets_dir="$TARGETS_DIR"
  local legacy_root="${WHMCS_ROOT:-}"
  local legacy_user="${WHMCS_RUN_USER:-}"
  local legacy_php="${PHP_BIN:-}"
  local legacy_composer="${COMPOSER_BIN:-}"

  if [[ -n "${REQUESTED_TARGET:-}" ]]; then
    TARGET_NAME="$REQUESTED_TARGET"
  elif [[ -n "${DEFAULT_TARGET:-}" ]]; then
    TARGET_NAME="$DEFAULT_TARGET"
  elif [[ -n "$legacy_root" ]]; then
    TARGET_NAME="default"
  else
    fail "DEFAULT_TARGET is not configured"
  fi
  validate_target_id "$TARGET_NAME"

  for path in "$TARGETS_DIR" "$REPOS_ROOT" "$STATE_ROOT" "$BACKUP_ROOT"; do
    [[ "$path" == /* ]] || fail "manager paths must be absolute: $path"
  done

  local profile
  profile="$(target_profile_for "$TARGET_NAME")"
  LEGACY_SINGLE_TARGET=0
  if [[ -f "$profile" ]]; then
    [[ ! -L "$profile" ]] || fail "target profile must not be a symlink: $profile"
    secure_root_owned_path "$profile" "target profile"
    unset WHMCS_ROOT WHMCS_RUN_USER PHP_BIN COMPOSER_BIN
    # shellcheck disable=SC1090
    source "$profile"
    # Target profiles may define only WHMCS runtime values; global manager settings stay global.
    REPOS_ROOT="$global_repos_root"
    STATE_ROOT="$global_state_root"
    BACKUP_ROOT="$global_backup_root"
    GIT_REMOTE="$global_git_remote"
    TRUSTED_TAG_SIGNING_FINGERPRINT="$global_fingerprint"
    GITHUB_APP_CLIENT_ID="$global_github_client_id"
    TARGETS_DIR="$global_targets_dir"
  elif [[ -n "$legacy_root" && "$TARGET_NAME" == "default" ]]; then
    LEGACY_SINGLE_TARGET=1
    WHMCS_ROOT="$legacy_root"
    WHMCS_RUN_USER="$legacy_user"
    PHP_BIN="$legacy_php"
    COMPOSER_BIN="$legacy_composer"
    warn "using legacy single-target config; reinstall or migrate config to /etc/whmcsmod/targets before adding more WHMCS instances"
  else
    fail "target profile not found: $profile"
  fi

  : "${WHMCS_ROOT:?WHMCS_ROOT is required in target profile}"
  : "${WHMCS_RUN_USER:?WHMCS_RUN_USER is required in target profile}"
  : "${PHP_BIN:=php}"
  if [[ ! ${COMPOSER_BIN+x} ]]; then COMPOSER_BIN="composer"; fi

  [[ -f "$MANIFEST_TOOL" && ! -L "$MANIFEST_TOOL" ]] || fail "manifest helper not found: $MANIFEST_TOOL"
  command -v "$PHP_BIN" >/dev/null 2>&1 || fail "PHP CLI not found: $PHP_BIN"
  PHP_BIN="$(command -v "$PHP_BIN")"
  if [[ -n "$COMPOSER_BIN" ]]; then
    command -v "$COMPOSER_BIN" >/dev/null 2>&1 || fail "Composer not found: $COMPOSER_BIN"
    COMPOSER_BIN="$(command -v "$COMPOSER_BIN")"
  fi

  [[ -f "$WHMCS_ROOT/init.php" ]] || fail "invalid WHMCS_ROOT for target $TARGET_NAME (init.php missing): $WHMCS_ROOT"
  [[ ! -L "$WHMCS_ROOT" ]] || fail "WHMCS_ROOT must not be a symlink"
  WHMCS_ROOT="$(cd "$WHMCS_ROOT" && pwd -P)"
  id -u "$WHMCS_RUN_USER" >/dev/null 2>&1 || fail "WHMCS_RUN_USER does not exist for target $TARGET_NAME: $WHMCS_RUN_USER"
  [[ "$WHMCS_RUN_USER" != "root" ]] || fail "WHMCS_RUN_USER must be the non-root WHMCS runtime user"

  if [[ -e "$TARGETS_DIR" ]]; then
    [[ -d "$TARGETS_DIR" && ! -L "$TARGETS_DIR" ]] || fail "invalid targets directory: $TARGETS_DIR"
    secure_root_owned_path "$TARGETS_DIR" "targets directory"
  elif [[ "$LEGACY_SINGLE_TARGET" == "0" ]]; then
    fail "targets directory not found: $TARGETS_DIR"
  fi

  for root in "$REPOS_ROOT" "$STATE_ROOT" "$BACKUP_ROOT"; do
    if [[ ! -e "$root" ]]; then install -d -m 0700 "$root"; fi
    [[ -d "$root" && ! -L "$root" ]] || fail "invalid manager directory: $root"
    secure_root_owned_path "$root" "manager directory"
  done
  REPOS_ROOT="$(cd "$REPOS_ROOT" && pwd -P)"
  MANAGER_STATE_ROOT="$(cd "$STATE_ROOT" && pwd -P)"
  MANAGER_BACKUP_ROOT="$(cd "$BACKUP_ROOT" && pwd -P)"

  if [[ "$LEGACY_SINGLE_TARGET" == "1" ]]; then
    STATE_ROOT="$MANAGER_STATE_ROOT"
    BACKUP_ROOT="$MANAGER_BACKUP_ROOT"
  else
    STATE_ROOT="$MANAGER_STATE_ROOT/targets/$TARGET_NAME"
    BACKUP_ROOT="$MANAGER_BACKUP_ROOT/$TARGET_NAME"
  fi
  install -d -m 0700 "$STATE_ROOT" "$STATE_ROOT/modules" "$BACKUP_ROOT"
}

manifest_get() {
  local manifest="$1" field="$2"
  "$PHP_BIN" "$MANIFEST_TOOL" get "$manifest" "$field" 2>/dev/null || return $?
}
manifest_bool() {
  local manifest="$1" field="$2"
  "$PHP_BIN" "$MANIFEST_TOOL" bool "$manifest" "$field" 2>/dev/null || return $?
}
manifest_list() {
  local manifest="$1" field="$2"
  "$PHP_BIN" "$MANIFEST_TOOL" list "$manifest" "$field" 2>/dev/null || return $?
}
manifest_validate() {
  "$PHP_BIN" "$MANIFEST_TOOL" validate "$1" "$2" >/dev/null
}

validate_module_id() {
  [[ "$1" =~ ^[a-z0-9][a-z0-9._-]{1,63}$ ]] || fail "invalid module id: $1"
}

semver_is_valid() {
  local version="$1" core prerelease identifier
  local -a identifiers=()
  [[ -n "$version" && "$version" != *+* ]] || return 1
  if [[ "$version" == *-* ]]; then
    core="${version%%-*}"
    prerelease="${version#*-}"
    [[ -n "$prerelease" && "$prerelease" != "$version" ]] || return 1
  else
    core="$version"
    prerelease=""
  fi
  [[ "$core" =~ ^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$ ]] || return 1
  [[ -z "$prerelease" ]] && return 0
  [[ "$prerelease" =~ ^[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*$ ]] || return 1
  IFS='.' read -r -a identifiers <<< "$prerelease"
  for identifier in "${identifiers[@]}"; do
    [[ -n "$identifier" ]] || return 1
    if [[ "$identifier" =~ ^[0-9]+$ && ${#identifier} -gt 1 && "$identifier" == 0* ]]; then
      return 1
    fi
  done
}

semver_is_stable() {
  semver_is_valid "$1" && [[ "$1" != *-* ]]
}

release_ref_version() {
  local ref="$1" prefix="$2" version
  [[ -n "$prefix" && "$ref" == "$prefix"* ]] || return 1
  version="${ref:${#prefix}}"
  semver_is_valid "$version" || return 1
  printf '%s\n' "$version"
}

repo_for() {
  local module="$1"
  validate_module_id "$module"
  local repo="$REPOS_ROOT/$module"
  [[ -d "$repo/.git" && ! -L "$repo" ]] || fail "module repository not found: $repo"
  echo "$(cd "$repo" && pwd -P)"
}

secure_repo() {
  local repo="$1"
  secure_root_owned_path "$repo" "repository"
  local issue
  issue="$(find "$repo/.git" -xdev \( ! -uid 0 -o -perm /022 \) -print -quit)"
  [[ -z "$issue" ]] || fail "repository metadata must be root-owned and not group/world writable: $issue"
}

run_home() {
  getent passwd 0 | awk -F: 'NR==1 {print $6}'
}

check_secure_git_home() {
  local home="$1" gpg_home
  [[ -n "$home" && -d "$home" && ! -L "$home" ]] || fail "unable to resolve safe root home"
  secure_root_owned_path "$home" "root home"
  gpg_home="$home/.gnupg"
  if [[ -e "$gpg_home" ]]; then
    [[ -d "$gpg_home" && ! -L "$gpg_home" ]] || fail "GPG home must be a regular directory: $gpg_home"
    secure_root_owned_path "$gpg_home" "GPG home"
  fi
}

repo_managed_identity() {
  local repo="$1" git identity
  git="$(command -v git)"
  identity="$(env -i PATH="$PATH" LANG=C LC_ALL=C GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null \
    "$git" -C "$repo" config --local --get whmcsmod.identityFile 2>/dev/null || true)"
  [[ -n "$identity" ]] || return 1
  printf '%s\n' "$identity"
}

git_repo() {
  local repo="$1"; shift
  local home ssh git gpg identity ssh_command known_hosts
  home="$(run_home)"
  check_secure_git_home "$home"
  git="$(command -v git)"
  gpg="$(command -v gpg)"
  ssh="$(command -v ssh)"
  ssh_command="$ssh"
  identity="$(repo_managed_identity "$repo" 2>/dev/null || true)"
  if [[ -n "$identity" ]]; then
    local key_root
    key_root="$(dirname "$CONFIG_FILE")/repo-keys"
    [[ "$identity" == "$key_root/"* ]] || fail "unsafe managed repository identity path: $identity"
    [[ "${identity#$key_root/}" =~ ^[A-Za-z0-9._-]+$ ]] || fail "unsafe managed repository identity path: $identity"
    [[ -f "$identity" && ! -L "$identity" ]] || fail "managed repository identity is missing or unsafe: $identity"
    secure_root_owned_path "$identity" "managed repository identity"
    known_hosts="$(dirname "$CONFIG_FILE")/github-known-hosts"
    [[ -f "$known_hosts" && ! -L "$known_hosts" ]] || fail "managed GitHub known-hosts file is missing: $known_hosts"
    secure_root_owned_path "$known_hosts" "managed GitHub known-hosts"
    ssh_command="$ssh -i $identity -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile=$known_hosts"
  fi
  env -i \
    PATH="$PATH" HOME="$home" GNUPGHOME="$home/.gnupg" LANG=C LC_ALL=C \
    GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null \
    GIT_SSH_COMMAND="$ssh_command" \
    "$git" -c core.hooksPath=/dev/null -c gpg.program="$gpg" \
    -c protocol.ext.allow=never -c protocol.file.allow=never -c core.fsmonitor=false \
    -C "$repo" "$@"
}

validate_remote() {
  local repo="$1" url
  url="$(git_repo "$repo" remote get-url "$GIT_REMOTE")" || fail "git remote not found: $GIT_REMOTE"
  [[ "$url" =~ ^ssh://[^[:space:]]+$ || "$url" =~ ^[^/@:[:space:]]+@[^/:[:space:]]+:.+$ ]] \
    || fail "production repositories must use SSH remotes; refusing: $url"
}

fetch_tags() {
  local repo="$1"
  validate_remote "$repo"
  git_repo "$repo" fetch --tags --prune "$GIT_REMOTE"
}

manifest_from_worktree() {
  local repo="$1" manifest="$repo/whmcs-module.json"
  [[ -f "$manifest" && ! -L "$manifest" ]] || fail "whmcs-module.json not found in $repo"
  echo "$manifest"
}

latest_tag() {
  local repo="$1" manifest="$2" prefix tag version
  prefix="$(manifest_get "$manifest" release.tag_prefix 2>/dev/null || echo v)"
  while IFS= read -r tag; do
    [[ "$tag" == "$prefix"* ]] || continue
    version="${tag:${#prefix}}"
    semver_is_stable "$version" || continue
    echo "$tag"
    return 0
  done < <(git_repo "$repo" tag --list "${prefix}*" --sort=-v:refname)
  return 0
}

verify_tag() {
  local repo="$1" ref="$2"
  local expected="${TRUSTED_TAG_SIGNING_FINGERPRINT//[[:space:]]/}"
  expected="${expected^^}"
  [[ "$expected" =~ ^[A-F0-9]{40,64}$ ]] || fail "TRUSTED_TAG_SIGNING_FINGERPRINT is missing or invalid"

  local tag_object output actual commit
  tag_object="$(git_repo "$repo" rev-parse -q --verify "refs/tags/$ref^{tag}")" \
    || fail "release must be an annotated tag: $ref"
  if ! output="$(git_repo "$repo" verify-tag --raw "$tag_object" 2>&1)"; then
    echo "$output" >&2
    fail "tag signature verification failed: $ref"
  fi
  actual="$(printf '%s\n' "$output" | awk '/^\[GNUPG:\] VALIDSIG / && !seen {print toupper($3); seen=1}')"
  [[ -n "$actual" ]] || fail "no VALIDSIG fingerprint found for $ref"
  [[ "$actual" == "$expected" ]] || fail "tag $ref was signed by untrusted fingerprint: $actual"
  commit="$(git_repo "$repo" rev-parse -q --verify "$tag_object^{commit}")" \
    || fail "tag does not resolve to a commit: $ref"
  echo "$commit"
}

cmd_target_list() {
  printf '%-20s %-9s %s\n' TARGET DEFAULT WHMCS_ROOT
  if [[ "$LEGACY_SINGLE_TARGET" == "1" ]]; then
    printf '%-20s %-9s %s\n' "$TARGET_NAME" yes "$WHMCS_ROOT"
    return 0
  fi

  local profile name root marker
  shopt -s nullglob
  for profile in "$TARGETS_DIR"/*.conf; do
    [[ -f "$profile" && ! -L "$profile" ]] || continue
    secure_root_owned_path "$profile" "target profile"
    name="$(basename "$profile" .conf)"
    validate_target_id "$name"
    root="$(
      unset WHMCS_ROOT WHMCS_RUN_USER PHP_BIN COMPOSER_BIN
      # shellcheck disable=SC1090
      source "$profile"
      printf '%s' "${WHMCS_ROOT:-missing}"
    )"
    marker=no
    [[ "$name" != "${DEFAULT_TARGET:-}" ]] || marker=yes
    printf '%-20s %-9s %s\n' "$name" "$marker" "$root"
  done
  shopt -u nullglob
}

cmd_target_show() {
  echo "Target:     $TARGET_NAME"
  echo "Default:    ${DEFAULT_TARGET:-$TARGET_NAME}"
  echo "WHMCS:      $WHMCS_ROOT"
  echo "Runtime:    $WHMCS_RUN_USER"
  echo "PHP:        $PHP_BIN"
  echo "Composer:   ${COMPOSER_BIN:-disabled}"
  echo "State:      $STATE_ROOT"
  echo "Backups:    $BACKUP_ROOT"
  if [[ "$LEGACY_SINGLE_TARGET" == "1" ]]; then
    echo "Profile:    legacy config ($CONFIG_FILE)"
  else
    echo "Profile:    $(target_profile_for "$TARGET_NAME")"
  fi
}

cmd_target_set_default() {
  local target="$1" profile parent tmp
  validate_target_id "$target"
  [[ "$LEGACY_SINGLE_TARGET" == "0" ]] || fail "legacy single-target config must be migrated before changing DEFAULT_TARGET"
  profile="$(target_profile_for "$target")"
  [[ -f "$profile" && ! -L "$profile" ]] || fail "target profile not found: $profile"
  secure_root_owned_path "$profile" "target profile"

  parent="$(dirname "$CONFIG_FILE")"
  tmp="$(mktemp "$parent/.whmcsmod-config.XXXXXX")"
  chmod 0600 "$tmp"
  awk -v target="$target" '
    BEGIN { changed=0 }
    /^DEFAULT_TARGET=/ {
      if (!changed) { print "DEFAULT_TARGET=\"" target "\""; changed=1 }
      next
    }
    { print }
    END { if (!changed) print "DEFAULT_TARGET=\"" target "\"" }
  ' "$CONFIG_FILE" > "$tmp"
  chown 0:0 "$tmp"
  mv -f -- "$tmp" "$CONFIG_FILE"
  chmod 0600 "$CONFIG_FILE"
  echo "Default target set to: $target"
}
