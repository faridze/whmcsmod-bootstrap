# Operational safety, planning, audit and backup management helpers.

manager_version() {
  local file value
  for file in "$LIB_DIR/VERSION" "$SELF_DIR/VERSION"; do
    [[ -f "$file" && ! -L "$file" ]] || continue
    value="$(tr -d '[:space:]' < "$file")"
    semver_is_stable "$value" || continue
    printf '%s\n' "$value"
    return 0
  done
  return 1
}

cmd_version() {
  local version
  version="$(manager_version)" || fail "unable to determine installed whmcsmod version"
  printf 'whmcsmod %s\n' "$version"
}

ops_config_scalar() {
  local key="$1" default="$2" line value
  line="$(grep -E "^${key}=" "$CONFIG_FILE" | tail -n1 2>/dev/null || true)"
  if [[ -z "$line" ]]; then
    printf '%s\n' "$default"
    return 0
  fi
  value="${line#*=}"
  value="${value//[[:space:]]/}"
  value="${value#\"}"; value="${value%\"}"
  value="${value#\'}"; value="${value%\'}"
  printf '%s\n' "$value"
}

backup_keep_default() {
  local keep
  keep="$(ops_config_scalar BACKUP_KEEP 10)"
  [[ "$keep" =~ ^[1-9][0-9]*$ ]] || fail "BACKUP_KEEP must be a positive integer"
  printf '%s\n' "$keep"
}

backup_auto_prune_enabled() {
  local enabled
  enabled="$(ops_config_scalar BACKUP_AUTO_PRUNE 0)"
  case "$enabled" in
    1|true|yes|on) return 0 ;;
    0|false|no|off|'') return 1 ;;
    *) fail "BACKUP_AUTO_PRUNE must be 0/1, true/false, yes/no, or on/off" ;;
  esac
}

backup_meta_value() {
  local backup="$1" key="$2" line
  [[ -f "$backup/meta" && ! -L "$backup/meta" ]] || return 1
  line="$(grep -F "${key}=" "$backup/meta" | head -n1 || true)"
  [[ -n "$line" ]] || return 1
  printf '%s\n' "${line#*=}"
}

backup_list_module() {
  local module="$1" root backup id created previous target
  validate_module_id "$module"
  root="$(backup_dir_for "$module")"
  [[ -e "$root" ]] || return 0
  [[ -d "$root" && ! -L "$root" ]] || fail "unsafe backup directory: $root"
  shopt -s nullglob
  local -a entries=("$root"/*)
  shopt -u nullglob
  ((${#entries[@]} > 0)) || return 0
  while IFS= read -r backup; do
    [[ -n "$backup" ]] || continue
    [[ -d "$backup" && ! -L "$backup" ]] || { warn "skipping unsafe backup entry: $backup"; continue; }
    id="$(basename "$backup")"
    created="$(backup_meta_value "$backup" created 2>/dev/null || echo '-')"
    previous="$(backup_meta_value "$backup" previous_ref 2>/dev/null || echo '-')"
    target="$(backup_meta_value "$backup" target_ref 2>/dev/null || echo '-')"
    printf '%-20s %-38s %-25s %-16s %-16s\n' "$module" "$id" "$created" "$previous" "$target"
  done < <(printf '%s\n' "${entries[@]}" | sort -r)
}

cmd_backup_list() {
  local requested="${1:---all}" module root
  printf '%-20s %-38s %-25s %-16s %-16s\n' MODULE BACKUP_ID CREATED PREVIOUS TARGET
  if [[ "$requested" != "--all" ]]; then
    backup_list_module "$requested"
    return 0
  fi
  shopt -s nullglob
  local -a roots=("$BACKUP_ROOT"/*)
  shopt -u nullglob
  for root in "${roots[@]}"; do
    [[ -d "$root" && ! -L "$root" ]] || continue
    module="$(basename "$root")"
    validate_module_id "$module"
    backup_list_module "$module"
  done
}

prune_module_backups() {
  local module="$1" keep="$2" root state last_backup='' backup index=0 removed=0 kept=0
  validate_module_id "$module"
  [[ "$keep" =~ ^[1-9][0-9]*$ ]] || fail "backup retention must be a positive integer"
  root="$(backup_dir_for "$module")"
  [[ -e "$root" ]] || { echo "$module: no backups"; return 0; }
  [[ -d "$root" && ! -L "$root" ]] || fail "unsafe backup directory: $root"
  root="$(cd "$root" && pwd -P)"
  state="$(state_dir_for "$module")"
  if [[ -f "$state/last-backup" && ! -L "$state/last-backup" ]]; then
    last_backup="$(cat "$state/last-backup")"
  fi

  shopt -s nullglob
  local -a entries=("$root"/*)
  shopt -u nullglob
  while IFS= read -r backup; do
    [[ -n "$backup" ]] || continue
    [[ -d "$backup" && ! -L "$backup" ]] || { warn "skipping unsafe backup entry: $backup"; continue; }
    [[ "$(dirname "$backup")" == "$root" ]] || fail "backup candidate escapes module root: $backup"
    if (( index < keep )); then
      index=$((index + 1)); kept=$((kept + 1)); continue
    fi
    index=$((index + 1))
    if [[ -n "$last_backup" && "$backup" == "$last_backup" ]]; then
      warn "$module: retaining recorded last-backup outside normal retention: $(basename "$backup")"
      kept=$((kept + 1))
      continue
    fi
    rm -rf --one-file-system -- "$backup"
    removed=$((removed + 1))
  done < <(printf '%s\n' "${entries[@]}" | sort -r)
  echo "$module: backup prune complete; kept=$kept removed=$removed retention=$keep"
}

cmd_backup_prune() {
  local module="--all" keep="" arg
  while (($#)); do
    arg="$1"
    case "$arg" in
      --keep)
        [[ $# -ge 2 ]] || fail "--keep requires a positive integer"
        [[ -z "$keep" ]] || fail "--keep specified more than once"
        keep="$2"; shift 2 ;;
      --keep=*)
        [[ -z "$keep" ]] || fail "--keep specified more than once"
        keep="${arg#--keep=}"; shift ;;
      --all)
        [[ "$module" == "--all" ]] || fail "backup prune accepts one module or --all"
        module="--all"; shift ;;
      --*) fail "unsupported backup prune option: $arg" ;;
      *)
        [[ "$module" == "--all" ]] || fail "backup prune accepts one module or --all"
        module="$arg"; shift ;;
    esac
  done
  [[ -n "$keep" ]] || keep="$(backup_keep_default)"
  [[ "$keep" =~ ^[1-9][0-9]*$ ]] || fail "--keep must be a positive integer"
  if [[ "$module" != "--all" ]]; then
    prune_module_backups "$module" "$keep"
    return 0
  fi
  local root name
  shopt -s nullglob
  local -a roots=("$BACKUP_ROOT"/*)
  shopt -u nullglob
  for root in "${roots[@]}"; do
    [[ -d "$root" && ! -L "$root" ]] || continue
    name="$(basename "$root")"
    validate_module_id "$name"
    prune_module_backups "$name" "$keep"
  done
}

maybe_auto_prune_backups() {
  local module="$1" keep
  backup_auto_prune_enabled || return 0
  keep="$(backup_keep_default)"
  prune_module_backups "$module" "$keep"
}

repo_audit_pick_tag() {
  local repo="$1" manifest="$2" prefix tag
  prefix="$(manifest_get "$manifest" release.tag_prefix 2>/dev/null || echo v)"
  while IFS= read -r tag; do
    release_ref_version "$tag" "$prefix" >/dev/null 2>&1 || continue
    printf '%s\n' "$tag"
    return 0
  done < <(git_repo "$repo" tag --list "${prefix}*" --sort=-v:refname)
  return 1
}

repo_audit_one() {
  local module="$1" repo manifest manifest_id slug remote identity expected_identity public_file mode pub_mode known_hosts actual_fp dirty tag key_id private_pub public_pub
  validate_module_id "$module"
  need_cmd git; need_cmd ssh; need_cmd ssh-keygen; need_cmd gpg; need_cmd sha256sum
  repo="$(repo_for "$module")"
  secure_repo "$repo"
  manifest="$repo/whmcs-module.json"
  manifest_validate "$manifest" "$repo"
  manifest_id="$(manifest_get "$manifest" id)"
  [[ "$manifest_id" == "$module" ]] || fail "manifest id '$manifest_id' does not match repository directory '$module'"

  slug="$(repo_git_direct "$repo" config --local --get whmcsmod.githubRepo 2>/dev/null || true)"
  [[ -n "$slug" ]] || fail "$module has no whmcsmod.githubRepo metadata"
  validate_github_repo_slug "$slug"
  remote="$(repo_git_direct "$repo" remote get-url "$GIT_REMOTE")"
  [[ "$remote" == "git@github.com:$slug.git" ]] || fail "$module remote is not the expected managed GitHub SSH URL: $remote"

  identity="$(repo_git_direct "$repo" config --local --get whmcsmod.identityFile 2>/dev/null || true)"
  [[ -n "$identity" ]] || fail "$module has no managed repository identity"
  expected_identity="$(repo_key_root)/$(repo_key_slug "$slug")"
  [[ "$identity" == "$expected_identity" ]] || fail "$module identity path does not match repository metadata: $identity"
  [[ -f "$identity" && ! -L "$identity" ]] || fail "$module private Deploy Key is missing or unsafe: $identity"
  secure_root_owned_path "$identity" "$module private Deploy Key"
  mode="$(stat -c '%a' "$identity")"
  [[ "$mode" == 600 ]] || fail "$module private Deploy Key mode must be 0600, found $mode"
  public_file="$identity.pub"
  [[ -f "$public_file" && ! -L "$public_file" ]] || fail "$module public Deploy Key is missing or unsafe: $public_file"
  secure_root_owned_path "$public_file" "$module public Deploy Key"
  pub_mode="$(stat -c '%a' "$public_file")"
  [[ "$pub_mode" == 644 ]] || fail "$module public Deploy Key mode must be 0644, found $pub_mode"
  private_pub="$(ssh-keygen -y -f "$identity" | awk '{print $1" "$2}')"
  public_pub="$(awk 'NR==1 {print $1" "$2}' "$public_file")"
  [[ -n "$private_pub" && "$private_pub" == "$public_pub" ]] || fail "$module public/private Deploy Key pair does not match"

  known_hosts="$(repo_known_hosts_file)"
  [[ -f "$known_hosts" && ! -L "$known_hosts" ]] || fail "managed GitHub known-hosts file is missing: $known_hosts"
  secure_root_owned_path "$known_hosts" "managed GitHub known-hosts"
  grep -Fx "$GITHUB_SSH_HOST_KEY" "$known_hosts" >/dev/null || fail "GitHub known-hosts does not contain the pinned ED25519 key"
  actual_fp="$(printf '%s\n' "$GITHUB_SSH_HOST_KEY" | ssh-keygen -lf - -E sha256 | awk '{print $2}')"
  [[ "$actual_fp" == "$GITHUB_SSH_ED25519_FINGERPRINT" ]] || fail "pinned GitHub SSH host fingerprint mismatch"

  key_id="$(repo_git_direct "$repo" config --local --get whmcsmod.deployKeyId 2>/dev/null || true)"
  [[ -z "$key_id" || "$key_id" =~ ^[0-9]+$ ]] || fail "$module has an invalid Deploy Key id: $key_id"
  dirty="$(repo_git_direct "$repo" status --porcelain --untracked-files=all)"
  [[ -z "$dirty" ]] || fail "$module repository worktree is dirty"

  tag="$(repo_audit_pick_tag "$repo" "$manifest" 2>/dev/null || true)"
  if [[ -n "$tag" ]]; then
    verify_tag "$repo" "$tag" >/dev/null
  fi
  printf '%s\t%s\t%s\t%s\n' "$module" "$slug" "${key_id:-manual}" "${tag:--}"
}

cmd_repo_audit() {
  local requested="${1:---all}" repo module output failures=0 checked=0
  printf '%-20s %-38s %-14s %-16s %s\n' MODULE REPOSITORY DEPLOY_KEY TAG RESULT
  if [[ "$requested" != "--all" ]]; then
    if output="$(repo_audit_one "$requested" 2>&1)"; then
      local slug key_id tag
      IFS=$'\t' read -r module slug key_id tag <<< "$output"
      printf '%-20s %-38s %-14s %-16s %s\n' "$module" "$slug" "$key_id" "$tag" OK
      return 0
    fi
    printf '%-20s %-38s %-14s %-16s %s\n' "$requested" - - - FAIL
    printf '%s\n' "$output" >&2
    return 1
  fi

  shopt -s nullglob
  local -a repos=("$REPOS_ROOT"/*)
  shopt -u nullglob
  for repo in "${repos[@]}"; do
    [[ -d "$repo/.git" && ! -L "$repo" && -f "$repo/whmcs-module.json" ]] || continue
    module="$(basename "$repo")"
    checked=$((checked + 1))
    if output="$(repo_audit_one "$module" 2>&1)"; then
      local slug key_id tag
      IFS=$'\t' read -r module slug key_id tag <<< "$output"
      printf '%-20s %-38s %-14s %-16s %s\n' "$module" "$slug" "$key_id" "$tag" OK
    else
      printf '%-20s %-38s %-14s %-16s %s\n' "$module" - - - FAIL
      printf '%s: %s\n' "$module" "$output" >&2
      failures=$((failures + 1))
    fi
  done
  echo "Repository audit: checked=$checked failed=$failures"
  (( failures == 0 ))
}

plan_contains_deploy_path() {
  local needle="$1" item
  for item in "${DEPLOY_FILES[@]}"; do
    [[ "$item" == "$needle" ]] && return 0
  done
  return 1
}

plan_update_one() {
  local module="$1" requested="${2:-latest}" state_dir manifest staged_id version current_ref current_version
  local relative target source_hash target_hash identical=0 changed=0 missing=0 unowned_existing=0 stale=0 composer_count=0 health_path validate_path remove_stale
  validate_module_id "$module"
  state_dir="$(state_dir_for "$module")"
  [[ -f "$state_dir/current-version" ]] || fail "$module is not managed yet; update planning applies only to managed modules"

  STAGE_REPO="" STAGE_DIR="" STAGE_SOURCE="" STAGE_REF="" STAGE_COMMIT="" HEALTHCHECK_TEMP=""
  DEPLOY_TEMPS=()
  stage_release "$module" "$requested"
  on_plan_exit() {
    local code=$?
    trap - EXIT
    set +e
    cleanup_stage
    exit "$code"
  }
  trap on_plan_exit EXIT

  manifest="$STAGE_SOURCE/whmcs-module.json"
  manifest_validate "$manifest" "$STAGE_SOURCE"
  staged_id="$(manifest_get "$manifest" id)"
  [[ "$staged_id" == "$module" ]] || fail "manifest id '$staged_id' does not match repository directory '$module'"
  version="$(check_release_consistency "$STAGE_SOURCE" "$manifest" "$STAGE_REF")"
  load_deploy_files "$STAGE_SOURCE" "$manifest"
  check_file_collisions "$module"
  current_ref="$(cat "$state_dir/current-ref" 2>/dev/null || echo '-')"
  current_version="$(cat "$state_dir/current-version" 2>/dev/null || echo '-')"

  for relative in "${DEPLOY_FILES[@]}"; do
    target="$WHMCS_ROOT/$relative"
    if [[ ! -f "$target" ]]; then
      missing=$((missing + 1))
      continue
    fi
    if [[ -f "$state_dir/current-files.txt" ]] && ! grep -Fxq "$relative" "$state_dir/current-files.txt"; then
      unowned_existing=$((unowned_existing + 1))
    fi
    source_hash="$(sha256sum "$STAGE_SOURCE/$relative" | awk '{print $1}')"
    target_hash="$(sha256sum "$target" | awk '{print $1}')"
    if [[ "$source_hash" == "$target_hash" ]]; then identical=$((identical + 1)); else changed=$((changed + 1)); fi
  done

  remove_stale="$(manifest_bool "$manifest" deploy.remove_stale 2>/dev/null || echo 1)"
  if [[ "$remove_stale" == 1 && -f "$state_dir/current-files.txt" ]]; then
    while IFS= read -r relative || [[ -n "$relative" ]]; do
      [[ -n "$relative" ]] || continue
      plan_contains_deploy_path "$relative" || stale=$((stale + 1))
    done < "$state_dir/current-files.txt"
  fi

  while IFS= read -r relative || [[ -n "$relative" ]]; do
    [[ -n "$relative" ]] && composer_count=$((composer_count + 1))
  done < <("$PHP_BIN" "$MANIFEST_TOOL" composer-paths "$manifest" 2>/dev/null || true)
  health_path="$(manifest_get "$manifest" hooks.healthcheck.path 2>/dev/null || true)"
  validate_path="$(manifest_get "$manifest" hooks.validate.path 2>/dev/null || true)"

  echo "Plan:       $module"
  echo "Current:    $current_ref ($current_version)"
  echo "Target:     $STAGE_REF ($version)"
  echo "Commit:     $STAGE_COMMIT"
  echo "Files:      ${#DEPLOY_FILES[@]}"
  echo "Identical:  $identical"
  echo "Changed:    $changed"
  echo "Missing/new: $missing"
  echo "Unowned existing paths:  $unowned_existing"
  echo "Stale to remove:          $stale"
  echo "Composer paths:           $composer_count"
  echo "Healthcheck migrate mode: $([[ -n "$health_path" ]] && echo yes || echo no)"
  echo "Validate hook:            $([[ -n "$validate_path" ]] && echo 'present (not executed during plan)' || echo none)"
  if [[ "$current_ref" == "$STAGE_REF" ]]; then
    echo "Backup:     no (release ref already installed; update would verify only)"
  else
    echo "Backup:     yes"
  fi
  echo "Mutation:   none to WHMCS files, module state, or backups"
  [[ "$unowned_existing" == 0 ]] || warn "$module: target release contains existing paths not present in current manager inventory"
  cleanup_stage
  trap - EXIT
}

plan_update_all() {
  local repo module failures=0 planned=0
  shopt -s nullglob
  local -a repos=("$REPOS_ROOT"/*)
  shopt -u nullglob
  for repo in "${repos[@]}"; do
    [[ -d "$repo/.git" && -f "$repo/whmcs-module.json" ]] || continue
    module="$(basename "$repo")"
    [[ -f "$(state_dir_for "$module")/current-version" ]] || continue
    (( planned == 0 )) || echo
    planned=$((planned + 1))
    if ! (plan_update_one "$module" latest); then failures=$((failures + 1)); fi
  done
  echo
  echo "Update plan summary: planned=$planned failed=$failures"
  (( failures == 0 ))
}

cmd_status_all() {
  local repo module manifest installed ref latest state
  printf '%-20s %-16s %-16s %-18s\n' MODULE INSTALLED AVAILABLE STATE
  shopt -s nullglob
  local -a repos=("$REPOS_ROOT"/*)
  shopt -u nullglob
  for repo in "${repos[@]}"; do
    [[ -d "$repo/.git" && -f "$repo/whmcs-module.json" ]] || continue
    module="$(basename "$repo")"
    manifest="$repo/whmcs-module.json"
    installed="$(cat "$(state_dir_for "$module")/current-version" 2>/dev/null || echo '-')"
    ref="$(cat "$(state_dir_for "$module")/current-ref" 2>/dev/null || echo '-')"
    latest="$(latest_tag "$repo" "$manifest" 2>/dev/null || true)"; [[ -n "$latest" ]] || latest="-"
    if [[ "$installed" == '-' ]]; then
      state="unmanaged"
    elif [[ "$latest" == '-' ]]; then
      state="managed"
    elif [[ "$ref" == "$latest" ]]; then
      state="current"
    else
      state="update-available"
    fi
    printf '%-20s %-16s %-16s %-18s\n' "$module" "$installed" "$latest" "$state"
  done
}

cmd_doctor_all() {
  local profile name failures=0 checked=0
  if [[ "$LEGACY_SINGLE_TARGET" == 1 ]]; then
    cmd_doctor
    return
  fi
  shopt -s nullglob
  local -a profiles=("$TARGETS_DIR"/*.conf)
  shopt -u nullglob
  for profile in "${profiles[@]}"; do
    [[ -f "$profile" && ! -L "$profile" ]] || continue
    name="$(basename "$profile" .conf)"
    validate_target_id "$name"
    checked=$((checked + 1))
    echo "== Target: $name =="
    if ! (
      REQUESTED_TARGET="$name"
      load_config
      cmd_doctor
      printf 'Disk free (WHMCS):  %s MB\n' "$(( $(df -Pk "$WHMCS_ROOT" | awk 'NR==2 {print $4}') / 1024 ))"
      printf 'Disk free (backup): %s MB\n' "$(( $(df -Pk "$BACKUP_ROOT" | awk 'NR==2 {print $4}') / 1024 ))"
    ); then
      failures=$((failures + 1))
    fi
    echo
  done
  echo "Doctor summary: targets=$checked failed=$failures"
  (( failures == 0 ))
}
