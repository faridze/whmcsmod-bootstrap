# Authenticated self-update for the central whmcsmod manager.
SELF_UPDATE_BASE_URL='https://raw.githubusercontent.com/faridze/whmcsmod-bootstrap/main'
SELF_UPDATE_SIGNING_FINGERPRINT='9A3FFFFD9AA2CDA1B825A9F90425CF942B02684C'
SELF_UPDATE_TEMP_DIR=''

self_update_stable_semver() {
  [[ "$1" =~ ^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$ ]]
}

self_update_version_cmp() {
  local a="$1" b="$2" a1 a2 a3 b1 b2 b3
  self_update_stable_semver "$a" && self_update_stable_semver "$b" || return 2
  IFS=. read -r a1 a2 a3 <<< "$a"
  IFS=. read -r b1 b2 b3 <<< "$b"
  if (( 10#$a1 != 10#$b1 )); then (( 10#$a1 > 10#$b1 )) && echo 1 || echo -1; return 0; fi
  if (( 10#$a2 != 10#$b2 )); then (( 10#$a2 > 10#$b2 )) && echo 1 || echo -1; return 0; fi
  if (( 10#$a3 != 10#$b3 )); then (( 10#$a3 > 10#$b3 )) && echo 1 || echo -1; return 0; fi
  echo 0
}

self_update_current_version() {
  local file value
  for file in "$LIB_DIR/VERSION" "$SELF_DIR/VERSION"; do
    [[ -f "$file" && ! -L "$file" ]] || continue
    value="$(tr -d '[:space:]' < "$file")"
    self_update_stable_semver "$value" || continue
    printf '%s\n' "$value"
    return 0
  done
  return 1
}

self_update_download() {
  local url="$1" destination="$2"
  [[ "$url" == https://* ]] || return 1
  curl -fsSL --proto '=https' --tlsv1.2 "$url" -o "$destination"
}

self_update_parse_metadata() {
  local metadata="$1" requested="${2:-}" line key value version='' sha256='' version_count=0 sha_count=0
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -n "$line" && "$line" == *=* ]] || return 1
    key="${line%%=*}"; value="${line#*=}"
    case "$key" in
      version) version_count=$((version_count + 1)); version="$value" ;;
      sha256) sha_count=$((sha_count + 1)); sha256="${value,,}" ;;
      *) return 1 ;;
    esac
  done < "$metadata"
  [[ $version_count -eq 1 && $sha_count -eq 1 ]] || return 1
  self_update_stable_semver "$version" || return 1
  [[ "$sha256" =~ ^[a-f0-9]{64}$ ]] || return 1
  [[ -z "$requested" || "$requested" == "$version" ]] || return 1
  SELF_UPDATE_RELEASE_VERSION="$version"
  SELF_UPDATE_RELEASE_SHA256="$sha256"
}

self_update_import_key() {
  local key_file="$1" gpg_home="$2" expected="$3"
  local -a fingerprints=()
  GNUPGHOME="$gpg_home" gpg --batch --import "$key_file" >/dev/null 2>&1 || return 1
  mapfile -t fingerprints < <(
    GNUPGHOME="$gpg_home" gpg --batch --with-colons --list-keys 2>/dev/null \
      | awk -F: '$1=="pub"{want=1;next} want&&$1=="fpr"{print toupper($10);want=0}'
  )
  [[ ${#fingerprints[@]} -eq 1 && "${fingerprints[0]}" == "$expected" ]]
}

self_update_verify_signature() {
  local metadata="$1" signature="$2" gpg_home="$3" expected="$4" status actual
  status="$(GNUPGHOME="$gpg_home" gpg --batch --status-fd=1 --verify "$signature" "$metadata" 2>/dev/null)" || return 1
  actual="$(printf '%s\n' "$status" | awk '/^\[GNUPG:\] VALIDSIG / && !seen {print toupper($3);seen=1}')"
  [[ -n "$actual" && "$actual" == "$expected" ]]
}

self_update_verify_archive_layout() {
  local archive="$1" entry normalized required listing
  local -a entries=()
  local -A seen=()
  listing="$(tar -tzf "$archive")" || return 1
  [[ -n "$listing" ]] || return 1
  mapfile -t entries <<< "$listing"
  ((${#entries[@]} >= 12)) || return 1
  for entry in "${entries[@]}"; do
    normalized="${entry#./}"
    [[ -n "$normalized" && "$normalized" != /* ]] || return 1
    [[ ! "$normalized" =~ (^|/)\.\.(/|$) ]] || return 1
    if [[ "$normalized" == VERSION || "$normalized" == install.sh || "$normalized" == whmcsmod || "$normalized" == lib/manifest.php || "$normalized" =~ ^lib/[A-Za-z0-9._-]+\.sh$ ]]; then
      :
    else
      return 1
    fi
    [[ -z "${seen[$normalized]+x}" ]] || return 1
    seen[$normalized]=1
  done
  for required in VERSION install.sh whmcsmod lib/commands.sh lib/common.sh lib/deploy.sh lib/install-detect.sh lib/manifest.php lib/ops.sh lib/release.sh lib/repo.sh lib/self-update.sh; do
    [[ -n "${seen[$required]+x}" ]] || return 1
  done
  if tar -tvzf "$archive" | awk '$1 !~ /^-/ {found=1} END {exit found ? 0 : 1}'; then
    return 1
  fi
}

self_update_cleanup() {
  if [[ -n "${SELF_UPDATE_TEMP_DIR:-}" ]]; then
    rm -rf -- "$SELF_UPDATE_TEMP_DIR"
    SELF_UPDATE_TEMP_DIR=''
  fi
}

cmd_self_update() (
  local mode='update' requested='' explicit=0
  if (($# == 1)); then
    if [[ "$1" == '--check' ]]; then mode='check'; else requested="$1"; explicit=1; fi
  elif (($# != 0)); then
    fail 'usage: whmcsmod self-update [--check|X.Y.Z]'
  fi
  [[ -z "$requested" ]] || self_update_stable_semver "$requested" || fail 'self-update version must be stable SemVer X.Y.Z'

  need_cmd curl; need_cmd gpg; need_cmd tar; need_cmd sha256sum
  local current configured key_file temp gpg_home metadata metadata_sig metadata_url artifact actual_sha cmp prefix release_dir installed
  current="$(self_update_current_version)" || fail 'unable to determine installed whmcsmod version'
  configured="${TRUSTED_TAG_SIGNING_FINGERPRINT//[[:space:]]/}"; configured="${configured^^}"
  [[ "$configured" == "$SELF_UPDATE_SIGNING_FINGERPRINT" ]] || fail 'configured signing fingerprint does not match the manager self-update trust anchor'
  [[ "${MANAGER_STATE_ROOT:-}" == /* && "${MANAGER_BACKUP_ROOT:-}" == /* ]] || fail 'global manager state/backup roots are unavailable'

  key_file="$(dirname "$CONFIG_FILE")/keys/release-signing-public.asc"
  [[ -f "$key_file" && ! -L "$key_file" ]] || fail "manager release public key is missing: $key_file"
  secure_root_owned_path "$key_file" 'manager release public key'

  temp="$(mktemp -d /tmp/whmcsmod-self-update.XXXXXX)"
  SELF_UPDATE_TEMP_DIR="$temp"
  trap self_update_cleanup EXIT
  gpg_home="$temp/gnupg"; mkdir -m 0700 "$gpg_home"
  metadata="$temp/release.meta"; metadata_sig="$temp/release.meta.asc"
  if [[ -n "$requested" ]]; then metadata_url="$SELF_UPDATE_BASE_URL/releases/$requested/release.meta"; else metadata_url="$SELF_UPDATE_BASE_URL/stable.meta"; fi
  self_update_download "$metadata_url" "$metadata" || fail 'unable to download self-update metadata'
  self_update_download "$metadata_url.asc" "$metadata_sig" || fail 'unable to download self-update metadata signature'
  self_update_import_key "$key_file" "$gpg_home" "$SELF_UPDATE_SIGNING_FINGERPRINT" || fail 'installed manager release key does not match the self-update trust anchor'
  self_update_verify_signature "$metadata" "$metadata_sig" "$gpg_home" "$SELF_UPDATE_SIGNING_FINGERPRINT" || fail 'self-update metadata signature is invalid or signed by an unexpected key'
  self_update_parse_metadata "$metadata" "$requested" || fail 'self-update metadata is malformed or does not match the requested stable version'

  cmp="$(self_update_version_cmp "$current" "$SELF_UPDATE_RELEASE_VERSION")" || fail 'unable to compare manager versions'
  echo "Current: $current"
  echo "Latest:  $SELF_UPDATE_RELEASE_VERSION"
  if (( cmp > 0 )); then
    (( explicit == 0 )) || fail "refusing self-update downgrade from $current to $SELF_UPDATE_RELEASE_VERSION"
    echo 'Installed manager is newer than the published stable release.'
    return 0
  fi
  if (( cmp == 0 )); then
    echo 'whmcsmod is already up to date.'
    return 0
  fi
  if [[ "$mode" == check ]]; then
    echo "Update available: $current -> $SELF_UPDATE_RELEASE_VERSION"
    return 0
  fi

  artifact="$temp/whmcsmod-$SELF_UPDATE_RELEASE_VERSION.tar.gz"
  self_update_download "$SELF_UPDATE_BASE_URL/releases/$SELF_UPDATE_RELEASE_VERSION/whmcsmod-$SELF_UPDATE_RELEASE_VERSION.tar.gz" "$artifact" || fail 'unable to download manager release artifact'
  actual_sha="$(sha256sum "$artifact" | awk '{print tolower($1)}')"
  [[ "$actual_sha" == "$SELF_UPDATE_RELEASE_SHA256" ]] || fail 'manager release artifact SHA-256 mismatch'
  self_update_verify_archive_layout "$artifact" || fail 'manager release artifact contains an unsafe or unexpected layout'

  release_dir="$temp/release"; mkdir -m 0700 "$release_dir"
  tar -xzf "$artifact" -C "$release_dir"
  [[ "$(tr -d '[:space:]' < "$release_dir/VERSION")" == "$SELF_UPDATE_RELEASE_VERSION" ]] || fail 'release bundle VERSION does not match signed metadata'
  [[ "$SELF_DIR" == */sbin ]] || fail 'self-update requires an installed whmcsmod under PREFIX/sbin'
  prefix="${SELF_DIR%/sbin}"

  local -a install_args=(
    --target "$TARGET_NAME"
    --whmcs-root "$WHMCS_ROOT"
    --whmcs-run-user "$WHMCS_RUN_USER"
    --php-bin "$PHP_BIN"
    --repos-root "$REPOS_ROOT"
    --state-root "$MANAGER_STATE_ROOT"
    --backup-root "$MANAGER_BACKUP_ROOT"
    --trusted-signing-public-key "$key_file"
    --trusted-signing-fingerprint "$SELF_UPDATE_SIGNING_FINGERPRINT"
    --prefix "$prefix"
    --config "$CONFIG_FILE"
    --targets-dir "$TARGETS_DIR"
  )
  [[ -z "$COMPOSER_BIN" ]] || install_args+=(--composer-bin "$COMPOSER_BIN")

  echo "Updating whmcsmod $current -> $SELF_UPDATE_RELEASE_VERSION ..."
  bash "$release_dir/install.sh" "${install_args[@]}"
  installed="$(tr -d '[:space:]' < "$prefix/lib/whmcsmod/VERSION")"
  [[ "$installed" == "$SELF_UPDATE_RELEASE_VERSION" ]] || fail 'installed manager VERSION does not match the authenticated release'
  "$prefix/sbin/whmcsmod" doctor
  echo "SUCCESS: whmcsmod updated $current -> $SELF_UPDATE_RELEASE_VERSION"
)
