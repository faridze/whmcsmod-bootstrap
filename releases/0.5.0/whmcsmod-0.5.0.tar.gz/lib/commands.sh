# User-facing commands.
cmd_adopt() {
  local module="$1" requested="${2:-latest}"
  validate_module_id "$module"
  local state_dir
  state_dir="$(state_dir_for "$module")"
  [[ ! -f "$state_dir/current-version" ]] || fail "$module is already managed"

  STAGE_REPO="" STAGE_DIR="" STAGE_SOURCE="" STAGE_REF="" STAGE_COMMIT="" HEALTHCHECK_TEMP=""
  DEPLOY_TEMPS=()
  stage_release "$module" "$requested"
  on_adopt_exit() {
    local code=$?
    trap - EXIT
    set +e
    cleanup_stage
    exit "$code"
  }
  trap on_adopt_exit EXIT

  local manifest="$STAGE_SOURCE/whmcs-module.json"
  manifest_validate "$manifest" "$STAGE_SOURCE"
  local staged_id version relative source_hash target_hash errors=0
  staged_id="$(manifest_get "$manifest" id)"
  [[ "$staged_id" == "$module" ]] || fail "manifest id '$staged_id' does not match repository directory '$module'"
  version="$(check_release_consistency "$STAGE_SOURCE" "$manifest" "$STAGE_REF")"
  run_validate_hook "$STAGE_SOURCE" "$manifest"
  load_deploy_files "$STAGE_SOURCE" "$manifest"
  check_file_collisions "$module"

  for relative in "${DEPLOY_FILES[@]}"; do
    if [[ ! -f "$WHMCS_ROOT/$relative" ]]; then
      echo "$module: MISSING $relative" >&2
      errors=$((errors + 1))
      continue
    fi
    source_hash="$(sha256sum "$STAGE_SOURCE/$relative" | awk '{print $1}')"
    target_hash="$(sha256sum "$WHMCS_ROOT/$relative" | awk '{print $1}')"
    if [[ "$source_hash" != "$target_hash" ]]; then
      echo "$module: CHANGED $relative" >&2
      errors=$((errors + 1))
    fi
  done
  if (( errors != 0 )); then
    fail "$module cannot be adopted as $STAGE_REF because $errors managed file(s) do not match the signed release"
  fi

  run_healthcheck "$STAGE_SOURCE" "$manifest" check
  write_state "$module" "$STAGE_REF" "$version" "$STAGE_COMMIT"
  echo "$module: adopted existing deployment as $STAGE_REF"
  cleanup_stage
  trap - EXIT
}

cmd_list() {
  printf '%-20s %-16s %-16s\n' MODULE INSTALLED LOCAL_TAG
  local repo module manifest installed latest
  shopt -s nullglob
  for repo in "$REPOS_ROOT"/*; do
    [[ -d "$repo/.git" && -f "$repo/whmcs-module.json" ]] || continue
    module="$(basename "$repo")"
    manifest="$repo/whmcs-module.json"
    installed="$(cat "$(state_dir_for "$module")/current-version" 2>/dev/null || echo '-')"
    latest="$(latest_tag "$repo" "$manifest" 2>/dev/null || true)"
    [[ -n "$latest" ]] || latest="-"
    printf '%-20s %-16s %-16s\n' "$module" "$installed" "$latest"
  done
  shopt -u nullglob
}

cmd_status() {
  local module="$1" repo state manifest latest
  repo="$(repo_for "$module")"
  state="$(state_dir_for "$module")"
  manifest="$(manifest_from_worktree "$repo")"
  latest="$(latest_tag "$repo" "$manifest" 2>/dev/null || true)"
  echo "Module:    $module"
  echo "Installed: $(cat "$state/current-version" 2>/dev/null || echo not-installed)"
  echo "Ref:       $(cat "$state/current-ref" 2>/dev/null || echo -)"
  echo "Local tag: ${latest:--}"
  echo "Repo:      $repo"
  echo "WHMCS:     $WHMCS_ROOT"
}

cmd_check_one() {
  local module="$1" repo manifest latest current
  repo="$(repo_for "$module")"
  secure_repo "$repo"
  fetch_tags "$repo"
  manifest="$(manifest_from_worktree "$repo")"
  latest="$(latest_tag "$repo" "$manifest")"
  current="$(cat "$(state_dir_for "$module")/current-ref" 2>/dev/null || echo not-installed)"
  echo "$module: installed=$current available=${latest:-none}"
}

cmd_check_all() {
  local repo
  shopt -s nullglob
  for repo in "$REPOS_ROOT"/*; do
    [[ -d "$repo/.git" && -f "$repo/whmcs-module.json" ]] || continue
    cmd_check_one "$(basename "$repo")"
  done
  shopt -u nullglob
}

cmd_verify() {
  local module="$1" state hash relative expected actual errors=0
  state="$(state_dir_for "$module")"
  [[ -f "$state/current-files.sha256" ]] || fail "$module has no installed inventory"
  while read -r hash relative; do
    [[ -n "$hash" && -n "$relative" ]] || continue
    expected="$hash"
    if [[ ! -f "$WHMCS_ROOT/$relative" ]]; then
      echo "MISSING  $relative"
      errors=$((errors+1))
      continue
    fi
    actual="$(sha256sum "$WHMCS_ROOT/$relative" | awk '{print $1}')"
    if [[ "$actual" != "$expected" ]]; then
      echo "CHANGED  $relative"
      errors=$((errors+1))
    fi
  done < "$state/current-files.sha256"
  if ((errors == 0)); then echo "$module: deployed files verified"; else fail "$module: $errors file(s) drifted"; fi
}

cmd_history() {
  local module="$1" root backup
  root="$(backup_dir_for "$module")"
  [[ -d "$root" ]] || { echo "$module: no backups"; return 0; }
  shopt -s nullglob
  for backup in "$root"/*; do
    [[ -d "$backup" ]] || continue
    printf '%s  ' "$(basename "$backup")"
    tr '\n' ' ' < "$backup/meta" 2>/dev/null || true
    echo
  done | sort -r
  shopt -u nullglob
}

cmd_rollback() {
  local module="$1" requested="${2:-last}" state root backup
  state="$(state_dir_for "$module")"
  root="$(backup_dir_for "$module")"
  if [[ "$requested" == "last" ]]; then
    [[ -f "$state/last-backup" ]] || fail "$module has no recorded last backup"
    backup="$(cat "$state/last-backup")"
  else
    [[ "$requested" =~ ^[A-Za-z0-9._:-]+$ ]] || fail "invalid backup id"
    backup="$root/$requested"
  fi
  [[ "$backup" == "$root/"* ]] || fail "backup path escapes module backup root"
  echo "$module: restoring $(basename "$backup")"
  restore_backup "$module" "$backup"
  date -Is > "$STATE_ROOT/modules/$module/last-rollback" 2>/dev/null || true
  echo "$module: code rollback completed"
  warn "database migrations are not reversed"
}

cmd_doctor() {
  need_cmd git; need_cmd gpg; need_cmd ssh; need_cmd tar; need_cmd flock; need_cmd sha256sum; need_cmd runuser
  echo "Config:     OK ($CONFIG_FILE)"
  echo "WHMCS:      OK ($WHMCS_ROOT)"
  echo "Runtime:    OK ($WHMCS_RUN_USER)"
  echo "PHP:        $($PHP_BIN -r 'echo PHP_VERSION;')"
  echo "Composer:   ${COMPOSER_BIN:-disabled}"
  echo "Repos:      $REPOS_ROOT"
  echo "State:      $STATE_ROOT"
  echo "Backups:    $BACKUP_ROOT"
  local fingerprint home gpg_home
  fingerprint="${TRUSTED_TAG_SIGNING_FINGERPRINT//[[:space:]]/}"
  fingerprint="${fingerprint^^}"
  if [[ ! "$fingerprint" =~ ^[A-F0-9]{40,64}$ ]]; then
    echo "Signing key: NOT CONFIGURED"
    return 1
  fi
  home="$(run_home)"
  check_secure_git_home "$home"
  gpg_home="$home/.gnupg"
  local fingerprints
  if [[ ! -d "$gpg_home" ]]; then
    echo "Signing key: fingerprint configured but public key is missing from $gpg_home"
    return 1
  fi
  fingerprints="$(GNUPGHOME="$gpg_home" gpg --batch --with-colons --list-keys 2>/dev/null \
    | awk -F: '$1 == "fpr" {print toupper($10)}')" || {
      echo "Signing key: unable to read $gpg_home"
      return 1
    }
  if ! grep -Fx "$fingerprint" <<< "$fingerprints" >/dev/null; then
    echo "Signing key: fingerprint configured but public key is missing from $gpg_home"
    return 1
  fi
  echo "Signing key: configured and present"
}

