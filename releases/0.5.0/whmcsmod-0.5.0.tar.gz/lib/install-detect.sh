# Installation-time runtime detection helpers.

whmcsmod_validate_runtime_user() {
  local user="$1"
  [[ -n "$user" && "$user" != root ]] || {
    echo "WHMCS runtime user must be a non-root local account" >&2
    return 1
  }
  id -u "$user" >/dev/null 2>&1 || {
    echo "WHMCS runtime user is not a valid local account: $user" >&2
    return 1
  }
}

whmcsmod_detect_runtime_user() {
  local whmcs_root="$1" init user
  init="$whmcs_root/init.php"
  [[ -f "$init" && ! -L "$init" ]] || {
    echo "Invalid WHMCS root: init.php must be a regular non-symlink file" >&2
    return 1
  }
  user="$(stat -c '%U' "$init" 2>/dev/null || true)"
  whmcsmod_validate_runtime_user "$user" || {
    echo "Unable to determine non-root WHMCS runtime user; pass --whmcs-run-user USER" >&2
    return 1
  }
  printf '%s\n' "$user"
}

whmcsmod_php_detection_error() {
  echo "Unable to determine the WHMCS PHP CLI safely." >&2
  echo "Re-run with:" >&2
  echo "  --php-bin /absolute/path/to/php" >&2
}

whmcsmod_unique_realpaths() {
  local candidate real existing
  local -a unique=()
  for candidate in "$@"; do
    [[ -n "$candidate" && -x "$candidate" && ! -d "$candidate" ]] || continue
    real="$(readlink -f "$candidate" 2>/dev/null || true)"
    [[ -n "$real" && -x "$real" ]] || continue
    for existing in "${unique[@]:-}"; do
      [[ "$existing" != "$real" ]] || { real=""; break; }
    done
    [[ -n "$real" ]] && unique+=("$real")
  done
  printf '%s\n' "${unique[@]:-}"
}

whmcsmod_select_unique_php_candidate() {
  local -a unique=()
  local item
  while IFS= read -r item; do
    [[ -n "$item" ]] && unique+=("$item")
  done < <(whmcsmod_unique_realpaths "$@")
  if ((${#unique[@]} == 1)); then
    printf '%s\n' "${unique[0]}"
    return 0
  fi
  whmcsmod_php_detection_error
  if ((${#unique[@]} > 1)); then
    echo "Detected multiple PHP CLI candidates:" >&2
    printf '  %s\n' "${unique[@]}" >&2
  fi
  return 1
}

whmcsmod_php_marker_candidates() {
  local whmcs_root="$1" htaccess token version
  htaccess="$whmcs_root/.htaccess"
  [[ -f "$htaccess" && ! -L "$htaccess" ]] || return 0

  while IFS= read -r token; do
    [[ -n "$token" ]] || continue
    version="${token#ea-php}"
    printf '/opt/cpanel/ea-php%s/root/usr/bin/php\n' "$version"
  done < <(grep -Eo 'ea-php[0-9]{2}' "$htaccess" 2>/dev/null | sort -u || true)

  while IFS= read -r token; do
    [[ -n "$token" ]] || continue
    version="${token##*php}"
    printf '/usr/local/php%s/bin/php\n' "$version"
  done < <(grep -Eo 'application/x-httpd-php[0-9]{2}' "$htaccess" 2>/dev/null | sort -u || true)

  grep -Eo '/usr/local/php[0-9]{2}/bin/php' "$htaccess" 2>/dev/null | sort -u || true
}

whmcsmod_detect_php() {
  local whmcs_root="$1" candidate system_php
  local -a markers=() candidates=()

  while IFS= read -r candidate; do
    [[ -n "$candidate" ]] && markers+=("$candidate")
  done < <(whmcsmod_php_marker_candidates "$whmcs_root")

  if ((${#markers[@]} > 0)); then
    whmcsmod_select_unique_php_candidate "${markers[@]}"
    return $?
  fi

  shopt -s nullglob
  for candidate in /usr/local/php??/bin/php /opt/cpanel/ea-php??/root/usr/bin/php; do
    [[ -x "$candidate" ]] && candidates+=("$candidate")
  done
  shopt -u nullglob

  system_php="$(command -v php 2>/dev/null || true)"
  [[ -n "$system_php" ]] && candidates+=("$system_php")
  whmcsmod_select_unique_php_candidate "${candidates[@]}"
}

whmcsmod_detect_composer() {
  local candidate path
  local -a candidates=() unique=()
  for candidate in /usr/local/bin/composer /usr/bin/composer; do
    [[ -x "$candidate" ]] && candidates+=("$candidate")
  done
  path="$(command -v composer 2>/dev/null || true)"
  [[ -n "$path" ]] && candidates+=("$path")
  while IFS= read -r path; do
    [[ -n "$path" ]] && unique+=("$path")
  done < <(whmcsmod_unique_realpaths "${candidates[@]:-}")
  if ((${#unique[@]} == 1)); then
    printf '%s\n' "${unique[0]}"
  elif ((${#unique[@]} > 1)); then
    echo "Composer auto-detection is ambiguous; continuing without Composer. Use --composer-bin /absolute/path/to/composer if needed." >&2
  fi
}
