# Repository onboarding and per-repository SSH identity management.

GITHUB_SSH_HOST_KEY='github.com ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl'
GITHUB_SSH_ED25519_FINGERPRINT='SHA256:+DiY3wvvV6TuJJhbpZisF/zLDA0zPMSvHdkr4UvCOqU'

validate_github_repo_slug() {
  local slug="$1" owner repo
  [[ "$slug" == */* && "$slug" != */*/* ]] || fail "GitHub repository must be OWNER/REPO: $slug"
  owner="${slug%%/*}"
  repo="${slug#*/}"
  [[ "$owner" =~ ^[A-Za-z0-9][A-Za-z0-9-]{0,38}$ ]] || fail "invalid GitHub owner: $owner"
  [[ "$repo" =~ ^[A-Za-z0-9._-]{1,100}$ ]] || fail "invalid GitHub repository name: $repo"
  [[ "$repo" != . && "$repo" != .. ]] || fail "invalid GitHub repository name: $repo"
}

repo_key_root() { printf '%s/repo-keys\n' "$(dirname "$CONFIG_FILE")"; }
repo_known_hosts_file() { printf '%s/github-known-hosts\n' "$(dirname "$CONFIG_FILE")"; }

repo_key_slug() {
  local slug="$1" value
  value="${slug,,}"
  value="${value//\//--}"
  [[ "$value" =~ ^[a-z0-9][a-z0-9._-]{1,200}$ ]] || fail "unable to derive safe repository key name"
  printf '%s\n' "$value"
}

ensure_github_known_hosts() {
  local file parent tmp actual
  file="$(repo_known_hosts_file)"
  parent="$(dirname "$file")"
  install -d -m 0755 "$parent"
  if [[ -e "$file" ]]; then
    [[ -f "$file" && ! -L "$file" ]] || fail "unsafe GitHub known-hosts path: $file"
    secure_root_owned_path "$file" "GitHub known-hosts"
    grep -Fx "$GITHUB_SSH_HOST_KEY" "$file" >/dev/null || fail "GitHub known-hosts file does not contain the pinned ED25519 key"
    return 0
  fi
  tmp="$(mktemp "$parent/.github-known-hosts.XXXXXX")"
  printf '%s\n' "$GITHUB_SSH_HOST_KEY" > "$tmp"
  chmod 0644 "$tmp"
  chown root:root "$tmp"
  actual="$(printf '%s\n' "$GITHUB_SSH_HOST_KEY" | ssh-keygen -lf - -E sha256 | awk '{print $2}')"
  [[ "$actual" == "$GITHUB_SSH_ED25519_FINGERPRINT" ]] || { rm -f -- "$tmp"; fail "pinned GitHub SSH host key fingerprint mismatch"; }
  mv -f -- "$tmp" "$file"
}

github_json_field() {
  local field="$1"
  "$PHP_BIN" -r '
    $raw = stream_get_contents(STDIN);
    try { $j = json_decode($raw, true, 32, JSON_THROW_ON_ERROR); }
    catch (Throwable $e) { fwrite(STDERR, "invalid GitHub JSON response\n"); exit(2); }
    $k = $argv[1]; $v = $j[$k] ?? null;
    if ($v === null) exit(4);
    if (!is_scalar($v)) exit(2);
    echo (string)$v;
  ' "$field"
}

github_device_token() {
  local client_id response device_code user_code verification_uri expires_in interval started now token error
  client_id="${GITHUB_APP_CLIENT_ID:-}"
  [[ "$client_id" =~ ^[A-Za-z0-9_-]{8,128}$ ]] || fail "GITHUB_APP_CLIENT_ID is not configured; use repo add ... --manual or configure the whmcsmod GitHub App client ID"
  need_cmd curl
  response="$(curl -fsS -X POST -H 'Accept: application/json' --data-urlencode "client_id=$client_id" https://github.com/login/device/code)" || fail "GitHub device authorization request failed"
  device_code="$(printf '%s' "$response" | github_json_field device_code)" || fail "GitHub device response is missing device_code"
  user_code="$(printf '%s' "$response" | github_json_field user_code)" || fail "GitHub device response is missing user_code"
  verification_uri="$(printf '%s' "$response" | github_json_field verification_uri)" || fail "GitHub device response is missing verification_uri"
  expires_in="$(printf '%s' "$response" | github_json_field expires_in)" || fail "GitHub device response is missing expires_in"
  interval="$(printf '%s' "$response" | github_json_field interval 2>/dev/null || printf '5')"
  [[ "$expires_in" =~ ^[0-9]+$ && "$interval" =~ ^[0-9]+$ ]] || fail "invalid GitHub device authorization timing"
  printf 'Open on your phone: %s\nCode: %s\nWaiting for GitHub approval...\n' "$verification_uri" "$user_code" >&2
  started="$(date +%s)"
  while :; do
    sleep "$interval"
    response="$(curl -fsS -X POST -H 'Accept: application/json' --data-urlencode "client_id=$client_id" --data-urlencode "device_code=$device_code" --data-urlencode 'grant_type=urn:ietf:params:oauth:grant-type:device_code' https://github.com/login/oauth/access_token)" || fail "GitHub device token request failed"
    token="$(printf '%s' "$response" | github_json_field access_token 2>/dev/null || true)"
    if [[ -n "$token" ]]; then printf '%s\n' "$token"; return 0; fi
    error="$(printf '%s' "$response" | github_json_field error 2>/dev/null || true)"
    case "$error" in
      authorization_pending|'') ;;
      slow_down) interval=$((interval + 5)) ;;
      expired_token) fail "GitHub device code expired; run the command again" ;;
      access_denied) fail "GitHub device authorization was denied" ;;
      *) fail "GitHub device authorization failed: $error" ;;
    esac
    now="$(date +%s)"
    (( now - started < expires_in )) || fail "GitHub device authorization timed out"
  done
}

github_api_with_token() {
  local token="$1" method="$2" path="$3" body="${4:-}" tmp_headers status
  tmp_headers="$(mktemp /tmp/whmcsmod-github-auth.XXXXXX)"
  chmod 0600 "$tmp_headers"
  printf 'Authorization: Bearer %s\n' "$token" > "$tmp_headers"
  if [[ -n "$body" ]]; then
    status="$(curl -sS -o "$GITHUB_API_BODY" -w '%{http_code}' -X "$method" -H "@$tmp_headers" -H 'Accept: application/vnd.github+json' -H 'X-GitHub-Api-Version: 2022-11-28' -H 'Content-Type: application/json' --data-binary "$body" "https://api.github.com$path")" || { rm -f -- "$tmp_headers"; return 1; }
  else
    status="$(curl -sS -o "$GITHUB_API_BODY" -w '%{http_code}' -X "$method" -H "@$tmp_headers" -H 'Accept: application/vnd.github+json' -H 'X-GitHub-Api-Version: 2022-11-28' "https://api.github.com$path")" || { rm -f -- "$tmp_headers"; return 1; }
  fi
  rm -f -- "$tmp_headers"
  printf '%s\n' "$status"
}

github_create_deploy_key() {
  local token="$1" slug="$2" title="$3" public_key="$4" body status id
  GITHUB_API_BODY="$(mktemp /tmp/whmcsmod-github-body.XXXXXX)"
  body="$("$PHP_BIN" -r 'echo json_encode(["title"=>$argv[1],"key"=>$argv[2],"read_only"=>true], JSON_UNESCAPED_SLASHES);' "$title" "$public_key")"
  status="$(github_api_with_token "$token" POST "/repos/$slug/keys" "$body")" || { rm -f -- "$GITHUB_API_BODY"; fail "GitHub deploy-key API request failed"; }
  if [[ "$status" != 201 ]]; then
    echo "GitHub API response:" >&2
    cat "$GITHUB_API_BODY" >&2 || true
    rm -f -- "$GITHUB_API_BODY"
    fail "GitHub refused the read-only deploy key (HTTP $status); ensure the GitHub App is installed on this repo with Administration: write"
  fi
  id="$(github_json_field id < "$GITHUB_API_BODY")" || { rm -f -- "$GITHUB_API_BODY"; fail "GitHub deploy-key response is missing id"; }
  rm -f -- "$GITHUB_API_BODY"
  [[ "$id" =~ ^[0-9]+$ ]] || fail "invalid GitHub deploy-key id"
  printf '%s\n' "$id"
}

github_delete_deploy_key() {
  local token="$1" slug="$2" key_id="$3" status
  GITHUB_API_BODY="$(mktemp /tmp/whmcsmod-github-body.XXXXXX)"
  status="$(github_api_with_token "$token" DELETE "/repos/$slug/keys/$key_id")" || { rm -f -- "$GITHUB_API_BODY"; fail "GitHub deploy-key delete request failed"; }
  rm -f -- "$GITHUB_API_BODY"
  [[ "$status" == 204 ]] || fail "GitHub refused deploy-key deletion (HTTP $status)"
}

repo_git_direct() {
  local repo="$1"; shift
  local git
  git="$(command -v git)"
  env -i PATH="$PATH" LANG=C LC_ALL=C GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$git" -c core.hooksPath=/dev/null -c protocol.ext.allow=never -c protocol.file.allow=never -C "$repo" "$@"
}

repo_clone_github() {
  local slug="$1" identity="$2" destination="$3" ssh git known_hosts ssh_command
  ssh="$(command -v ssh)"; git="$(command -v git)"; known_hosts="$(repo_known_hosts_file)"
  ssh_command="$ssh -i $identity -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile=$known_hosts"
  env -i PATH="$PATH" HOME="$(run_home)" LANG=C LC_ALL=C GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_SSH_COMMAND="$ssh_command" "$git" -c core.hooksPath=/dev/null -c protocol.ext.allow=never -c protocol.file.allow=never clone --origin "$GIT_REMOTE" "git@github.com:$slug.git" "$destination"
}

repo_deploy_key_title() {
  local host
  host="$(hostname -s 2>/dev/null || hostname)"
  host="${host//[^A-Za-z0-9._-]/-}"
  printf 'whmcsmod %s %s\n' "$host" "$1"
}

repo_register_manual_key() {
  local slug="$1" public_key="$2"
  printf '\nAdd this as a READ-ONLY Deploy Key in GitHub:\nRepository: %s\nSettings -> Deploy keys -> Add deploy key\n\n%s\n\n' "$slug" "$public_key" >&2
  if [[ -t 0 ]]; then read -r -p 'Press Enter after the key has been added to GitHub... ' _; else fail "--manual requires an interactive terminal to confirm the Deploy Key was added"; fi
}

repo_any_managed_state() {
  local module="$1" hit
  hit="$(find "$MANAGER_STATE_ROOT" -xdev -type f -path "*/modules/$module/current-version" -print -quit 2>/dev/null || true)"
  [[ -n "$hit" ]]
}

cmd_repo_add() {
  local slug="$1" mode="${2:-}" manual=0 key_root key_name identity public_file public_key token='' key_id='' stage='' manifest module destination title latest committed=0
  [[ "$mode" == "" || "$mode" == "--manual" ]] || fail "unsupported repo add option: $mode"
  [[ "$mode" == "--manual" ]] && manual=1
  validate_github_repo_slug "$slug"
  need_cmd git; need_cmd ssh; need_cmd ssh-keygen; need_cmd hostname; need_cmd date; need_cmd sleep
  ensure_github_known_hosts
  key_root="$(repo_key_root)"
  install -d -m 0700 "$key_root"
  secure_root_owned_path "$key_root" "repository key directory"
  key_name="$(repo_key_slug "$slug")"
  identity="$key_root/$key_name"
  public_file="$identity.pub"
  [[ ! -e "$identity" && ! -e "$public_file" ]] || fail "repository identity already exists: $identity"
  ssh-keygen -q -t ed25519 -f "$identity" -N '' -C "whmcsmod:$slug" >/dev/null
  chmod 0600 "$identity"; chmod 0644 "$public_file"; chown root:root "$identity" "$public_file"
  public_key="$(cat "$public_file")"
  title="$(repo_deploy_key_title "$slug")"

  cleanup_repo_add() {
    local rc=$?
    if (( committed == 0 )); then
      [[ -n "$stage" && -d "$stage" ]] && rm -rf -- "$stage"
      rm -f -- "$identity" "$public_file"
      if [[ -n "$token" && -n "$key_id" ]]; then github_delete_deploy_key "$token" "$slug" "$key_id" >/dev/null 2>&1 || true; fi
    fi
    return "$rc"
  }
  trap cleanup_repo_add EXIT

  if (( manual == 1 )); then
    repo_register_manual_key "$slug" "$public_key"
  else
    token="$(github_device_token)"
    key_id="$(github_create_deploy_key "$token" "$slug" "$title" "$public_key")"
    echo "GitHub authorized; read-only Deploy Key created." >&2
  fi

  stage="$(mktemp -d "$REPOS_ROOT/.whmcsmod-repo-add.XXXXXX")"
  rmdir "$stage"
  repo_clone_github "$slug" "$identity" "$stage"
  [[ -d "$stage/.git" && ! -L "$stage" ]] || fail "cloned repository is invalid"
  secure_repo "$stage"
  manifest="$stage/whmcs-module.json"
  [[ -f "$manifest" && ! -L "$manifest" ]] || fail "whmcs-module.json not found in cloned repository"
  manifest_validate "$manifest" "$stage"
  module="$(manifest_get "$manifest" id)"
  validate_module_id "$module"
  destination="$REPOS_ROOT/$module"
  [[ ! -e "$destination" ]] || fail "module repository destination already exists: $destination"

  repo_git_direct "$stage" config --local whmcsmod.identityFile "$identity"
  repo_git_direct "$stage" config --local whmcsmod.githubRepo "$slug"
  if [[ -n "$key_id" ]]; then repo_git_direct "$stage" config --local whmcsmod.deployKeyId "$key_id"; fi
  repo_git_direct "$stage" remote set-url "$GIT_REMOTE" "git@github.com:$slug.git"
  mv -- "$stage" "$destination"
  stage=''
  secure_repo "$destination"
  fetch_tags "$destination"
  latest="$(latest_tag "$destination" "$destination/whmcs-module.json")"
  committed=1
  trap - EXIT

  echo "Repository added:"
  echo "  Module:     $module"
  echo "  Repository: $slug"
  echo "  Path:       $destination"
  echo "  Identity:   $identity"
  echo "  Latest:     ${latest:--}"
  echo
  echo "No WHMCS files were deployed."
}

cmd_repo_list() {
  local repo module slug identity
  printf '%-20s %-38s %s\n' MODULE REPOSITORY IDENTITY
  shopt -s nullglob
  for repo in "$REPOS_ROOT"/*; do
    [[ -d "$repo/.git" && ! -L "$repo" && -f "$repo/whmcs-module.json" ]] || continue
    module="$(manifest_get "$repo/whmcs-module.json" id 2>/dev/null || basename "$repo")"
    slug="$(repo_git_direct "$repo" config --local --get whmcsmod.githubRepo 2>/dev/null || true)"
    identity="$(repo_git_direct "$repo" config --local --get whmcsmod.identityFile 2>/dev/null || true)"
    printf '%-20s %-38s %s\n' "$module" "${slug:--}" "${identity:--}"
  done
  shopt -u nullglob
}

cmd_repo_status() {
  local module="$1" repo slug identity key_id remote latest manifest
  repo="$(repo_for "$module")"; secure_repo "$repo"; manifest="$repo/whmcs-module.json"
  slug="$(repo_git_direct "$repo" config --local --get whmcsmod.githubRepo 2>/dev/null || true)"
  identity="$(repo_git_direct "$repo" config --local --get whmcsmod.identityFile 2>/dev/null || true)"
  key_id="$(repo_git_direct "$repo" config --local --get whmcsmod.deployKeyId 2>/dev/null || true)"
  remote="$(git_repo "$repo" remote get-url "$GIT_REMOTE")"
  latest="$(latest_tag "$repo" "$manifest")"
  printf 'Module:      %s\nPath:        %s\nRepository:  %s\nRemote:      %s\nIdentity:    %s\nDeploy key:  %s\nLatest tag:  %s\n' "$module" "$repo" "${slug:--}" "$remote" "${identity:--}" "${key_id:--}" "${latest:--}"
}

cmd_repo_refresh() {
  local module="$1" repo manifest latest
  repo="$(repo_for "$module")"; secure_repo "$repo"; manifest="$repo/whmcs-module.json"
  fetch_tags "$repo"
  latest="$(latest_tag "$repo" "$manifest")"
  echo "$module: repository metadata refreshed; latest stable tag: ${latest:--}"
}

cmd_repo_remove() {
  local module="$1" mode="${2:-}" manual=0 repo slug identity public_file key_id token=''
  [[ "$mode" == "" || "$mode" == "--manual" ]] || fail "unsupported repo remove option: $mode"
  [[ "$mode" == "--manual" ]] && manual=1
  validate_module_id "$module"
  repo="$(repo_for "$module")"; secure_repo "$repo"
  repo_any_managed_state "$module" && fail "refusing to remove repository while module has managed deployment state: $module"
  slug="$(repo_git_direct "$repo" config --local --get whmcsmod.githubRepo 2>/dev/null || true)"
  identity="$(repo_git_direct "$repo" config --local --get whmcsmod.identityFile 2>/dev/null || true)"
  key_id="$(repo_git_direct "$repo" config --local --get whmcsmod.deployKeyId 2>/dev/null || true)"
  [[ -n "$slug" && -n "$identity" ]] || fail "repository was not onboarded by whmcsmod; remove it manually"
  public_file="$identity.pub"
  if (( manual == 1 )); then
    printf 'Remove the whmcsmod Deploy Key from GitHub first:\nRepository: %s\nSettings -> Deploy keys\n' "$slug" >&2
    if [[ -t 0 ]]; then read -r -p 'Press Enter after the Deploy Key has been removed... ' _; else fail "--manual requires an interactive terminal"; fi
  else
    [[ "$key_id" =~ ^[0-9]+$ ]] || fail "missing GitHub deploy-key id; use --manual"
    token="$(github_device_token)"
    github_delete_deploy_key "$token" "$slug" "$key_id"
  fi
  rm -rf -- "$repo"
  rm -f -- "$identity" "$public_file"
  echo "Repository removed: $module ($slug)"
}
