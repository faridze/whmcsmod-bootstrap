# Release staging and transactional install/update/takeover logic.
acquire_global_lock() {
  local lock_root="${MANAGER_STATE_ROOT:-$STATE_ROOT}"
  install -d -m 0700 "$lock_root"
  exec 9>"$lock_root/manager.lock"
  flock -n 9 || fail "another WHMCS module deployment is already running"
}

stage_release() {
  need_cmd git; need_cmd gpg; need_cmd ssh
  local module="$1" requested="$2" repo manifest ref commit stage source version
  repo="$(repo_for "$module")"
  secure_repo "$repo"
  fetch_tags "$repo"
  manifest="$(manifest_from_worktree "$repo")"
  "$PHP_BIN" "$MANIFEST_TOOL" validate "$manifest" >/dev/null
  if [[ "$requested" == "latest" ]]; then
    ref="$(latest_tag "$repo" "$manifest")"
    [[ -n "$ref" ]] || fail "no stable semantic release tag found for $module"
  else
    ref="$requested"
  fi
  local prefix
  prefix="$(manifest_get "$manifest" release.tag_prefix 2>/dev/null || echo v)"
  version="$(release_ref_version "$ref" "$prefix")" || fail "release ref must be a semantic tag: ${prefix}X.Y.Z[-prerelease]"
  commit="$(verify_tag "$repo" "$ref")"
  stage="$(mktemp -d "$STATE_ROOT/stage.${module}.XXXXXX")"
  source="$stage/source"
  STAGE_REPO="$repo"
  STAGE_DIR="$stage"
  STAGE_SOURCE="$source"
  STAGE_REF="$ref"
  STAGE_COMMIT="$commit"
  if ! git_repo "$repo" worktree add --detach "$source" "$commit" >/dev/null; then
    cleanup_stage
    fail "unable to create detached release worktree for $ref"
  fi
}

cleanup_stage() {
  if [[ -n "${HEALTHCHECK_TEMP:-}" ]]; then rm -f -- "$HEALTHCHECK_TEMP" || true; fi
  local temp
  for temp in "${DEPLOY_TEMPS[@]:-}"; do [[ -n "$temp" ]] && rm -f -- "$temp" || true; done
  if [[ -n "${STAGE_SOURCE:-}" && -n "${STAGE_REPO:-}" ]]; then
    git_repo "$STAGE_REPO" worktree remove --force "$STAGE_SOURCE" >/dev/null 2>&1 || true
  fi
  [[ -z "${STAGE_DIR:-}" ]] || rm -rf -- "$STAGE_DIR" || true
  STAGE_REPO="" STAGE_DIR="" STAGE_SOURCE="" STAGE_REF="" STAGE_COMMIT=""
}

update_one() {
  local module="$1" requested="${2:-latest}" mode="${3:-update}"
  validate_module_id "$module"
  local state_dir installed=0
  state_dir="$(state_dir_for "$module")"
  [[ -f "$state_dir/current-version" ]] && installed=1
  if [[ "$mode" == "install" && "$installed" == "1" ]]; then fail "$module is already installed"; fi
  if [[ "$mode" == "update" && "$installed" == "0" ]]; then fail "$module is not managed yet; use install for a new module, adopt for an exact existing deployment, or takeover for a differing legacy deployment"; fi

  STAGE_REPO="" STAGE_DIR="" STAGE_SOURCE="" STAGE_REF="" STAGE_COMMIT="" HEALTHCHECK_TEMP=""
  DEPLOY_TEMPS=()
  stage_release "$module" "$requested"
  on_stage_exit() {
    local code=$?
    trap - EXIT
    set +e
    cleanup_stage
    exit "$code"
  }
  trap on_stage_exit EXIT

  local manifest="$STAGE_SOURCE/whmcs-module.json"
  manifest_validate "$manifest" "$STAGE_SOURCE"
  local staged_id version
  staged_id="$(manifest_get "$manifest" id)"
  [[ "$staged_id" == "$module" ]] || fail "manifest id '$staged_id' does not match repository directory '$module'"
  version="$(check_release_consistency "$STAGE_SOURCE" "$manifest" "$STAGE_REF")"

  if [[ "$installed" == "1" && "$(cat "$state_dir/current-ref")" == "$STAGE_REF" ]]; then
    echo "$module: already at $STAGE_REF"
    cmd_verify "$module"
    cleanup_stage
    trap - EXIT
    return 0
  fi

  run_validate_hook "$STAGE_SOURCE" "$manifest"
  load_deploy_files "$STAGE_SOURCE" "$manifest"
  check_file_collisions "$module"
  if [[ "$mode" == "install" ]]; then assert_install_targets_free; fi

  local union_file backup deployment_started=0 deployment_success=0
  union_file="$(mktemp "$STATE_ROOT/union.${module}.XXXXXX")"
  union_inventory "$state_dir" "$union_file"
  backup="$(backup_current_state "$module" "$STAGE_REF" "$union_file")"
  backup_composer_vendors "$backup" "$manifest"
  rm -f -- "$union_file"

  on_update_exit() {
    local code=$?
    trap - EXIT
    set +e
    if (( code != 0 && deployment_started == 1 && deployment_success == 0 )); then
      echo "$PROGRAM: deployment failed; restoring $module from $backup" >&2
      restore_backup "$module" "$backup" || true
    fi
    cleanup_stage
    exit "$code"
  }
  trap on_update_exit EXIT

  echo "$module: deploying $STAGE_REF ..."
  deployment_started=1
  copy_deploy_files "$STAGE_SOURCE"
  remove_stale_files "$state_dir" "$manifest"
  run_composer "$manifest"
  run_healthcheck "$STAGE_SOURCE" "$manifest" migrate
  write_state "$module" "$STAGE_REF" "$version" "$STAGE_COMMIT"
  echo "$backup" > "$state_dir/last-backup"
  deployment_success=1

  echo "$module: deployment successful ($STAGE_REF)"
  echo "$module: backup $backup"
  cleanup_stage
  trap - EXIT
}

takeover_one() {
  local module="$1" requested="$2" dry_run="${3:-0}"
  validate_module_id "$module"
  [[ "$requested" != "latest" ]] || fail "takeover requires an explicit signed release tag"
  [[ "$dry_run" == "0" || "$dry_run" == "1" ]] || fail "invalid takeover dry-run mode"

  local state_dir existing_state
  state_dir="$(state_dir_for "$module")"
  [[ ! -L "$state_dir" ]] || fail "module state path must not be a symlink: $state_dir"
  if [[ -e "$state_dir" && ! -d "$state_dir" ]]; then
    fail "module state path is not a directory: $state_dir"
  fi
  existing_state=""
  if [[ -d "$state_dir" ]]; then
    existing_state="$(find "$state_dir" -mindepth 1 -maxdepth 1 -print -quit)"
  fi
  [[ -z "$existing_state" ]] || fail "$module already has manager state; use update instead of takeover"

  STAGE_REPO="" STAGE_DIR="" STAGE_SOURCE="" STAGE_REF="" STAGE_COMMIT="" HEALTHCHECK_TEMP=""
  DEPLOY_TEMPS=()
  stage_release "$module" "$requested"
  on_takeover_stage_exit() {
    local code=$?
    trap - EXIT
    set +e
    cleanup_stage
    exit "$code"
  }
  trap on_takeover_stage_exit EXIT

  local manifest="$STAGE_SOURCE/whmcs-module.json" staged_id version
  manifest_validate "$manifest" "$STAGE_SOURCE"
  staged_id="$(manifest_get "$manifest" id)"
  [[ "$staged_id" == "$module" ]] || fail "manifest id '$staged_id' does not match repository directory '$module'"
  version="$(check_release_consistency "$STAGE_SOURCE" "$manifest" "$STAGE_REF")"
  run_validate_hook "$STAGE_SOURCE" "$manifest"
  load_deploy_files "$STAGE_SOURCE" "$manifest"
  check_file_collisions "$module"
  classify_takeover_files "$STAGE_SOURCE"

  if [[ "$dry_run" == "1" ]]; then
    echo "$module: takeover dry-run valid for $STAGE_REF"
    cleanup_stage
    trap - EXIT
    return 0
  fi

  local union_file backup deployment_started=0 deployment_success=0
  union_file="$(mktemp "$STATE_ROOT/union.${module}.XXXXXX")"
  union_inventory "$state_dir" "$union_file"
  backup="$(backup_current_state "$module" "$STAGE_REF" "$union_file")"
  backup_composer_vendors "$backup" "$manifest"
  rm -f -- "$union_file"

  on_takeover_exit() {
    local code=$?
    trap - EXIT
    set +e
    if (( code != 0 && deployment_started == 1 && deployment_success == 0 )); then
      echo "$PROGRAM: takeover failed; restoring $module from $backup" >&2
      restore_backup "$module" "$backup" || true
    fi
    cleanup_stage
    exit "$code"
  }
  trap on_takeover_exit EXIT

  echo "$module: taking over legacy deployment with $STAGE_REF ..."
  deployment_started=1
  copy_deploy_files "$STAGE_SOURCE"
  # There is no previous manager-owned inventory during first takeover.
  # Unknown/local legacy files are intentionally left untouched.
  run_composer "$manifest"
  run_healthcheck "$STAGE_SOURCE" "$manifest" migrate
  write_state "$module" "$STAGE_REF" "$version" "$STAGE_COMMIT"
  echo "$backup" > "$state_dir/last-backup"
  deployment_success=1

  echo "$module: takeover successful ($STAGE_REF)"
  echo "$module: backup $backup"
  cleanup_stage
  trap - EXIT
}
